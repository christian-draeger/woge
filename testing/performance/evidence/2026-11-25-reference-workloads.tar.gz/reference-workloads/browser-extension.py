#!/usr/bin/env python3
"""Run independently packaged hosts for the preregistered browser tasks."""
import argparse
import subprocess
from http_study import HERE, SPEC, dump, run_arrivals, server

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("phase", choices=("pilot", "measured", "shell"))
phase = parser.parse_args().phase
directory = HERE / f"browser-{phase}"
directory.mkdir()
rounds = SPEC["rotation"][:1] if phase == "pilot" else SPEC["rotation"]
for round_number, order in enumerate(rounds, 1):
    for host in order:
        block = directory / f"round-{round_number}-{host}"
        block.mkdir()
        with server(host, block) as (port, pid):
            dump(block / "warmup.json", run_arrivals(port, pid, 8, 4))
            with (block / "browser.log").open("w") as log:
                command = ["node", str(HERE / ("browser-shell.mjs" if phase == "shell" else "browser-extension.mjs")), str(port), host,
                           str(block / "browser.json"), str(round_number), phase]
                result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=220)
            print(host, round_number, result.returncode, flush=True)
