#!/usr/bin/env python3
"""Run the predeclared saturation extension without mutating the frozen study."""
import argparse
import json
import subprocess
import time
from http_study import HERE, SPEC, dump, expect, project_journey, resource_snapshot, run_arrivals, server, summarize

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("phase", choices=("load-pilot", "load-measured", "load-saturation"))
phase = parser.parse_args().phase
plan = json.loads((HERE / "extension-plan.json").read_text())["saturation"]
saturation = phase == "load-saturation"
if saturation:
    plan.update(json.loads((HERE / "saturation-amendment.json").read_text()))
SPEC["http"]["workerLimit"] = plan["workerLimit"]
SPEC["http"]["requestDeadlineMs"] = plan["socketDeadlineMs"]
directory = HERE / phase
directory.mkdir()
all_results = []
piloting = phase == "load-pilot"

def diagnostic(pid, output, *command):
    result = subprocess.run(["jcmd", str(pid), *command], timeout=15, capture_output=True, text=True)
    output.write_text(result.stdout + result.stderr)
    expect(result.returncode == 0 and "Exception" not in result.stdout, f"jcmd {command} did not complete")

for round_number, order in enumerate(SPEC["rotation"][:1] if piloting else SPEC["rotation"], 1):
    for host in order:
        block = directory / f"round-{round_number}-{host}"
        block.mkdir()
        with server(host, block) as (port, pid):
            dump(block / "warmup.json", run_arrivals(port, pid, 24, 4))
            rates = plan["ratesPerSecond"]
            for rate in rates[:2] if piloting else (rates if round_number % 2 else rates[::-1]):
                run = run_arrivals(port, pid, rate, 2 if piloting else plan["windowSeconds"])
                dump(block / f"{rate}.json", run)
                row = dict(host=host, round=round_number, rate=rate, **summarize(run))
                all_results.append(row)
                print(json.dumps(row), flush=True)
                time.sleep(1)
            controls = {}
            for name, options in (("native", {"native": True}), ("disconnected", {"disconnect": True}), ("afterDisconnect", {})):
                controls[name] = project_journey(port, time.monotonic_ns(), 2500, **options)
            time.sleep(1)
            controls["beforeRetentionProbe"] = resource_snapshot(pid, port)
            expect(controls["beforeRetentionProbe"]["establishedInbound"] == 0, "connections did not drain")
            expect(controls["native"]["outcome"] == controls["afterDisconnect"]["outcome"] == "correct", "recovery failed")
            expect(controls["disconnected"]["outcome"] == "disconnect-after-first", "disconnect probe failed")
            if phase == "load-measured":
                diagnostic(pid, block / "gc-before.txt", "GC.heap_info")
                diagnostic(pid, block / "gc-run.txt", "GC.run")
                diagnostic(pid, block / "gc-after.txt", "GC.heap_info")
                if round_number == 1:
                    diagnostic(pid, block / "jfr-start.txt", "JFR.start", "name=allocation", "settings=profile")
                    dump(block / "profiled-24.json", run_arrivals(port, pid, 24, 5))
                    recording = block / "allocation.jfr"
                    diagnostic(pid, block / "jfr-stop.txt", "JFR.stop", "name=allocation", f"filename={recording}")
                    with (block / "allocation-samples.json").open("w") as output:
                        subprocess.run(["jfr", "print", "--json", "--events", "jdk.ObjectAllocationSample", str(recording)],
                                       stdout=output, timeout=30, check=True)
            controls["afterRetentionProbe"] = resource_snapshot(pid, port)
            dump(block / "controls.json", controls)
        dump(directory / "summary.json", all_results)
