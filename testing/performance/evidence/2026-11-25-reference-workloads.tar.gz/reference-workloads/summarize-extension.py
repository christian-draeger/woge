#!/usr/bin/env python3
"""Summarize measured workloads from preserved raw files."""
from collections import Counter, defaultdict
from pathlib import Path
from statistics import median
import json
import re

here = Path(__file__).resolve().parent


def read(path):
    return json.loads(path.read_text())


def rounded(number):
    return round(number, 3)


def range_of(values):
    return {"median": rounded(median(values)), "range": [rounded(min(values)), rounded(max(values))]}


def http(phase):
    rows = defaultdict(list)
    for row in read(here / phase / "summary.json"):
        rows[row["host"], row["rate"]].append(row)
    result = []
    for (host, rate), rounds in sorted(rows.items()):
        outcomes = sum((Counter(row["outcomes"]) for row in rounds), Counter())
        complete = [row.get("scheduledToCompleteMs", {}) for row in rounds]
        result.append({
            "host": host, "plannedPerSecond": rate, "samples": sum(row["scheduled"] for row in rounds),
            "outcomes": dict(outcomes), "correctWithin750Ms": sum(row["within750Ms"] for row in rounds),
            "medianRoundP50Ms": range_of([row["p50"] for row in complete if "p50" in row]),
            "medianRoundP95Ms": range_of([row["p95"] for row in complete if "p95" in row]),
            "roundP99Ms": [row["p99"] for row in complete if "p99" in row],
            "generatorQueueP95Ms": range_of([row["generatorQueueMs"]["p95"] for row in rounds]),
            "dispatchP95Ms": range_of([row["dispatchToCompleteMs"]["p95"] for row in rounds if "dispatchToCompleteMs" in row]),
            "dispatchInWindowPerSecond": range_of([row["startedPerSecondInWindow"] for row in rounds]),
            "completionPerSecondThroughDrain": range_of([row["correctCompletionPerSecondThroughDrain"] for row in rounds]),
            "applicationCpuSeconds": range_of([row["cpuSeconds"] for row in rounds]),
        })
    return result


def nested(key, data):
    return key in data and data[key] is not None


def browser(phase):
    seen = defaultdict(list)
    failed = []
    for path in sorted((here / phase).glob("round-*/browser.json")):
        block = read(path)
        for row in block["results"]:
            if row["outcome"] != "correct":
                failed.append({"host": block["host"], "round": block["round"], **row})
                continue
            seen[block["host"], row["condition"], row["workload"], row["enhanced"]].append(row["result"])
    result = []
    for (host, condition, workload, enhanced), rows in sorted(seen.items()):
        values = defaultdict(list)
        for row in rows:
            observed = row.get("observation") or {}
            for key in ("shellAtMs", "usefulAtMs"):
                if nested(key, observed):
                    values[key].append(observed[key])
            for key in ("observedAtMs", "firstPaintMs", "parseToInteractiveMs"):
                if nested(key, row):
                    values[key].append(row[key])
            for key in ("rejection", "mutation"):
                if nested(key, row):
                    values[key + "ClickToObservedMs"].append(row[key]["clickToObservedMs"])
            if "statuses" in row:
                values["lastOfTwelveClickToObserverMs"].append(row["statuses"][-1]["lastPeerClickToObservedMs"])
            for metric, value in row.get("rendererMs", {}).items():
                values[metric].append(value)
            if row.get("resources"):
                categories = defaultdict(int)
                for resource in row["resources"]:
                    url = resource["path"]
                    if url.endswith(".css"):
                        kind = "css"
                    elif url.endswith(".js"):
                        kind = "wogeJs" if url.startswith("/assets/woge/") else "applicationAndUiJs"
                    elif resource["initiator"] == "navigation":
                        kind = "html"
                    elif "/woge-patches/" in url:
                        kind = "patch"
                    else:
                        kind = "other"
                    for metric in ("transferBytes", "encodedBodyBytes", "decodedBodyBytes"):
                        categories[kind + "." + metric] += resource[metric]
                for metric, value in categories.items():
                    values[metric].append(value)
        result.append({"host": host, "condition": condition, "workload": workload, "enhanced": enhanced,
                       "samples": len(rows), **{key: range_of(value) for key, value in values.items()}})
    return {"groups": result, "failures": failed}


def process():
    rows = defaultdict(list)
    for directory in sorted((here / "load-measured").glob("round-*")):
        host = directory.name.split("-", 2)[2]
        controls = read(directory / "controls.json")
        startup = read(directory / "startup.json")["initialProcessReadyMs"]
        jcmd = (directory / "gc-after.txt").read_text()
        heap = re.search(r"garbage-first heap\s+total (\d+)K, used (\d+)K", jcmd)
        if not heap:
            raise ValueError(f"{directory} lacks heap measurements")
        rows[host].append({
            "startupMs": startup, "heapCommittedKiB": int(heap[1]), "heapUsedAfterFullGcKiB": int(heap[2]),
            "rssBeforeFullGcKiB": controls["beforeRetentionProbe"]["rssKiB"],
            "rssAfterFullGcKiB": controls["afterRetentionProbe"]["rssKiB"],
            "postDrainSockets": controls["beforeRetentionProbe"]["establishedInbound"],
        })
    return {host: {key: range_of([row[key] for row in rounds]) for key in rounds[0]} for host, rounds in rows.items()}


def main():
    result = {"http": http("load-measured"), "process": process(), "browser": browser("browser-measured")}
    if (here / "load-saturation/summary.json").is_file():
        result["saturation"] = http("load-saturation")
    if (here / "browser-shell").is_dir():
        result["shell"] = browser("browser-shell")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
