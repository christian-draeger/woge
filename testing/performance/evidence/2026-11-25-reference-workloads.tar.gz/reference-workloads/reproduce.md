# Reproduce the fixed reference study

Use a disposable checkout at `7fb2f6616e4115b4fb0050f872bef669cf8c5b88`. Follow the archived
`manifest.json` build commands. Capture all independent distributions, and verify their exact
hashes where possible before labeling results as the same artifact set. The original one-time
reference package build log and exact launch commands are retained with the prior deferred study.

Extract the exact Linux arm64 Temurin 21.0.12.1+1 JDK, including jcmd and JFR, from
`eclipse-temurin@sha256:00c9122c5e827957e28ffe642f382a0671eb4f45cefb5f73bd79ad07f10f8e4c`.
Use the Node dependencies in the reference checkout with Playwright 1.62.1. The pinned Linux
Playwright image in `run.sh` supplies the browser and the standard runtime environment.
Set the following paths and use a fresh copy of the driver files, with no previous result
directories. Run workloads serially.

```sh
export WOGE_STUDY_REPO=/path/to/reference-checkout-with-packages
export WOGE_STUDY_LINUX_JAVA_HOME=/path/to/temurin-jdk
./run.sh python3 -B load-extension.py load-pilot
./run.sh python3 -B load-extension.py load-measured
./run.sh python3 -B browser-extension.py pilot
./run.sh python3 -B browser-extension.py measured
./run.sh python3 -B load-extension.py load-saturation
./run.sh python3 -B browser-extension.py shell
python3 summarize-extension.py > summary.json
```

The HTTP clock is Python monotonic and the browser uses its own performance time origin.
Browser clicks also have an independent automation observation deadline. Exporter invocation
and trace propagation are outside the reference configuration. The 24/s JFR control follows
the heap inspection and remains separate from all traffic comparisons. Archive file hashes are
in `SHA256SUMS`.

The unsuccessful browser calibration retained its exact DOM assertion errors and partially
completed result rows. The corrected driver scopes activity text to list items, avoids awaiting
the paused, disabled script context and validates terminal framing independently over HTTP.
The supplemental shell probe requires the actual visible full-navigation submit button;
the original enhanced selector targeted the no-JavaScript-only link. The first load setup used
an identically versioned JRE without the diagnostic utility. The unsuccessful partial run and
tool failure remain in `load-jre-calibration`. The full JDK is required for the report.
