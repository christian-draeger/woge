import { chromium } from "./repo/client/woge-fallback-client/node_modules/playwright/index.mjs";
import { expect } from "./repo/client/woge-fallback-client/node_modules/@playwright/test/index.mjs";
import { readFile, writeFile } from "node:fs/promises";
import { performance } from "node:perf_hooks";

const [port, host, output, round, mode] = process.argv.slice(2);
const origin = `http://127.0.0.1:${port}`;
const plan = JSON.parse(await readFile(new URL("./extension-plan.json", import.meta.url), "utf8")).browser;
const browser = await chromium.launch();
const project = "/projects/woge";
const board = project + "/tasks";
const taskRoute = /\/woge-actions\/add-board-task$/;
const noteRoute = /\/woge-actions\/add-note$/;
const results = [];
const conditions = [...plan.conditions];
if (Number(round) % 2 === 0) conditions.reverse();
if (mode === "pilot") conditions.splice(1, 2);


function observeStart() {
  globalThis.study = { patch: [], shellAtMs: null, usefulAtMs: null, css: null };
  const start = new WeakMap();
  document.addEventListener("woge:before-replace", event => start.set(event.target, performance.now()));
  document.addEventListener("woge:after-replace", event => {
    const now = performance.now();
    const prior = start.get(event.target);
    globalThis.study.patch.push({ atMs: now, eventIntervalMs: prior === undefined ? null : now - prior });
  });
  const visible = node => node?.getClientRects().length && getComputedStyle(node).visibility === "visible";
  const frame = () => {
    const data = globalThis.study;
    const heading = document.querySelector("main h1");
    if (data.shellAtMs === null && visible(heading) && heading.textContent === "Woge" &&
        visible(document.querySelector('a[href$="?view=complete"]')) &&
        document.querySelectorAll("[data-woge-region]").length === 3) {
      data.shellAtMs = performance.now();
    }
    const table = document.querySelector("main table");
    const activity = document.querySelector("main .activity-list");
    const settled = !document.querySelector(".is-loading") &&
      Array.from(document.querySelectorAll("main [data-woge-region]")).every(region => region.dataset.wogeRevision === "1");
    if (visible(table) && visible(activity) && settled &&
        table.textContent.includes("Verify the deferred browser path") &&
        activity.textContent.includes("Server adapter contract verified")) {
      data.usefulAtMs = performance.now();
    } else {
      requestAnimationFrame(frame);
    }
  };
  if (location.pathname === "/projects/woge") requestAnimationFrame(frame);
}

async function preparePage(context, condition, observe) {
  const page = await context.newPage();
  page.setDefaultTimeout(8000);
  const session = await context.newCDPSession(page);
  await session.send("Network.enable");
  await session.send("Network.setCacheDisabled", { cacheDisabled: condition.cache === "disabled" });
  if (condition.cpu > 1) {
    await session.send("Emulation.setCPUThrottlingRate", { rate: condition.cpu });
    await session.send("Network.emulateNetworkConditions", {
      offline: false,
      latency: condition.latencyMs,
      downloadThroughput: condition.downloadBytesPerSecond,
      uploadThroughput: condition.uploadBytesPerSecond,
    });
  }
  await session.send("Performance.enable");
  if (observe) await page.addInitScript(observeStart);
  return { page, session };
}

async function metrics(session) {
  return Object.fromEntries((await session.send("Performance.getMetrics")).metrics.map(
    item => [item.name, item.value]));
}

async function details(page, session, startMetrics, enhanced) {
  if (enhanced) await page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))));
  const current = await metrics(session);
  const rendererMs = Object.fromEntries(
    ["TaskDuration", "ScriptDuration", "LayoutDuration", "RecalcStyleDuration", "ScriptParsingDuration"]
      .filter(key => current[key] !== undefined && startMetrics[key] !== undefined)
      .map(key => [key, (current[key] - startMetrics[key]) * 1000]),
  );
  const timings = await page.evaluate(() => {
    const navigation = performance.getEntriesByType("navigation")[0];
    return {
      observedAtMs: performance.now(),
      firstPaintMs: performance.getEntriesByName("first-contentful-paint")[0]?.startTime,
      parseToInteractiveMs: navigation?.domInteractive,
      observation: globalThis.study,
      resources: [navigation, ...performance.getEntriesByType("resource")].filter(Boolean).map(entry => ({
        path: new URL(entry.name).pathname.replace(/\/woge-patches\/[^/]+$/, "/woge-patches/{epoch}"),
        initiator: entry.initiatorType,
        transferBytes: entry.transferSize,
        encodedBodyBytes: entry.encodedBodySize,
        decodedBodyBytes: entry.decodedBodySize,
      })),
    };
  });
  return { ...timings, rendererMs };
}

async function checkProject(page) {
  await expect(page.getByRole("heading", { name: "Woge", exact: true })).toBeVisible({timeout: 8000});
  const tasks = page.getByRole("table", { name: "Current tasks for Woge" });
  await expect(tasks).toBeVisible({timeout: 8000});
  for (const text of ["Publish the first web-first guide", "Verify the deferred browser path", "Record the architecture decision"]) {
    await expect(tasks.getByText(text, { exact: true })).toBeVisible();
  }
  for (const text of ["Standards-native CSS contract implemented", "Server adapter contract verified"]) {
    await expect(page.locator(".activity-list li").filter({ hasText: text })).toBeVisible();
  }
  await expect(page.locator(".is-loading")).toHaveCount(0);
}

async function navigation(page, session, enhanced, condition) {
  const url = origin + project + (enhanced ? "" : "?view=complete");
  if (condition.cache !== "disabled") {
    await page.goto(url);
    await checkProject(page);
  }
  const start = await metrics(session);
  const patch = enhanced ? page.waitForResponse(r => r.url().includes("/woge-patches/")) : null;
  patch?.catch(() => {});
  const response = await page.goto(url, { waitUntil: "load" });
  expect(response.status()).toBe(200);
  await checkProject(page);
  if (patch) {
    const stream = await patch;
    expect(stream.status()).toBe(200);
    expect(await stream.finished()).toBeNull();
    await expect(page.locator('[data-woge-region][data-woge-revision="1"]')).toHaveCount(3);
  }
  return {
    ...(await details(page, session, start, enhanced)),
    html: (await response.headerValue("content-encoding")) ?? "identity",
    patches: patch ? (await (await patch).headerValue("content-encoding")) ?? "identity" : null,
  };
}

async function notes(page, session, enhanced, condition) {
  const route = origin + "/notes";
  await page.goto(route);
  if (condition.cache !== "disabled") await page.reload();
  const input = page.getByLabel("New note");
  const button = page.getByRole("button", { name: "Add note" });
  await input.evaluate(element => element.removeAttribute("maxlength"));
  const oversized = "😀".repeat(61);
  await input.fill(oversized);
  const invalid = page.waitForResponse(r => r.request().method() === "POST" && noteRoute.test(r.url()));
  const rejectionMetrics = await metrics(session);
  const rejectionStart = performance.now();
  await button.click();
  const rejected = await invalid;
  expect(rejected.status()).toBe(400);
  await expect(page.locator("#note-errors")).toContainText("Use at most 120 UTF-16 code units.");
  await expect(input).toHaveValue(oversized);
  if (enhanced) await expect(page.locator("#note-errors")).toBeFocused();
  await expect(page.getByRole("listitem").filter({ hasText: oversized })).toHaveCount(0);
  const rejection = await details(page, session, rejectionMetrics, enhanced);
  rejection.clickToObservedMs = performance.now() - rejectionStart;
  rejection.httpStatus = rejected.status();
  const title = `Study ${round} ${condition.name} ${enhanced ? "enhanced" : "native"}`;
  await input.fill(title);
  const post = page.waitForResponse(r => r.request().method() === "POST" && noteRoute.test(r.url()));
  const submitMetrics = await metrics(session);
  const submitStart = performance.now();
  await button.click();
  const saved = await post;
  expect(saved.status()).toBe(enhanced ? 200 : 303);
  await expect(page.getByRole("listitem").filter({ hasText: title })).toHaveCount(1);
  if (enhanced) await expect(page.locator("#note-status")).toHaveText("Note added");
  const mutation = await details(page, session, submitMetrics, enhanced);
  mutation.clickToObservedMs = performance.now() - submitStart;
  mutation.httpStatus = saved.status();
  return { rejection, mutation };
}

async function seedBoard() {
  const context = await browser.newContext({ javaScriptEnabled: false });
  try {
    const api = context.request;
    for (let index = 1; index <= 80; index++) {
      const response = await api.get(origin + board + "?theme=tailwind");
      expect(response.status()).toBe(200);
      const html = await response.text();
      const values = {};
      for (const name of ["epoch", "version", "revision"]) {
        const field = html.match(new RegExp('<input[^>]+name="' + name + '"[^>]+value="([^"]+)"'));
        if (!field) throw new Error("board missing hidden form field " + name);
        values[name] = field[1];
      }
      const title = "Planned row " + String(index).padStart(3, "0");
      const posted = await api.post(origin + "/woge-actions/add-board-task", {
        headers: { Origin: origin },
        form: { ...values, title, owner: "Study team", priority: "Normal", status: "Open" },
        maxRedirects: 0,
      });
      expect(posted.status()).toBe(303);
    }
  } finally {
    await context.close();
  }
}

async function denseTable(page, session, enhanced, condition) {
  const path = origin + board + "?theme=tailwind";
  if (condition.cache !== "disabled") await page.goto(path);
  const start = await metrics(session);
  const response = await page.goto(path);
  expect(response.status()).toBe(200);
  const table = page.getByRole("table", { name: /Task delivery/ });
  await expect(table).toBeVisible();
  await expect(table.locator("tbody tr")).toHaveCount(8);
  await expect(table.getByRole("rowheader", { name: "Planned row 080", exact: true })).toBeVisible();
  await expect(page.locator("#task-count")).toContainText("81 tasks");
  await expect(page.getByRole("navigation", { name: "Task pages" })).toContainText("Page 1 of 11");
  const firstPage = await details(page, session, start, enhanced);
  await page.getByRole("link", { name: "Next tasks" }).click();
  await expect(page.getByRole("navigation", { name: "Task pages" })).toContainText("Page 2 of 11");
  await expect(table.locator("tbody tr")).toHaveCount(8);
  await expect(table.getByRole("rowheader", { name: "Planned row 072", exact: true })).toBeVisible();
  return firstPage;
}

async function live(page, session, enhanced, condition, context) {
  const opened = page.waitForResponse(r => r.url().includes("/projects/woge/tasks/live/"));
  opened.catch(() => {});
  await page.goto(origin + board, { waitUntil: "domcontentloaded" });
  expect((await opened).headers()["content-type"]).toContain("text/event-stream");
  const input = page.getByLabel("Task title");
  const draft = "Unsaved observer draft";
  await input.fill(draft);
  await input.focus();
  const peer = await context.newPage();
  try {
    await peer.goto(origin + board, { waitUntil: "domcontentloaded" });
    const peerInput = peer.getByLabel("Task title");
    const owner = peer.getByLabel("Owner", { exact: true });
    const statuses = [];
    const start = await metrics(session);
    const label = "Peer " + round + " " + condition.name;
    for (let index = 1; index <= 12; index++) {
      const title = label + " " + String(index).padStart(2, "0");
      await peerInput.fill(title);
      await owner.fill("Study team");
      const pending = peer.waitForResponse(r => r.request().method() === "POST" && taskRoute.test(r.url()));
      const started = performance.now();
      await peer.getByRole("button", { name: "Add task" }).click();
      expect((await pending).status()).toBe(200);
      await expect(peer.locator("#board-tasks li").filter({ hasText: title })).toHaveCount(1);
      if (index % 3 === 0) {
        await expect(page.locator("#board-activity")).toContainText(index + " tasks changed.");
        await expect(input).toHaveValue(draft);
        await expect(input).toBeFocused();
        statuses.push({ mutations: index, lastPeerClickToObservedMs: performance.now() - started });
      }
    }
    const timing = await details(page, session, start, enhanced);
    await page.locator("#board-activity").getByRole("link", { name: "Show the latest board" }).click();
    await expect(page.locator("#board-tasks li").filter({ hasText: label + " 12" })).toHaveCount(1);
    return { statuses, timing };
  } finally {
    await peer.close();
  }
}

async function runCase(condition, enhanced, name, action) {
  const settings = { viewport: { width: plan.viewport[0], height: plan.viewport[1] }, javaScriptEnabled: enhanced };
  const context = await browser.newContext(settings);
  const result = { condition: condition.name, enhanced, workload: name };
  try {
    const { page, session } = await preparePage(context, condition, enhanced);
    result.result = await action(page, session, enhanced, condition, context);
    result.outcome = "correct";
  } catch (error) {
    result.outcome = "error";
    result.problem = String(error);
  } finally {
    results.push(result);
    await writeFile(output, JSON.stringify({ host, round: Number(round), chromium: browser.version(), results }, null, 2) + "\n");
    await context.close();
  }
  console.log(condition.name, name, enhanced, result.outcome, result.problem ?? "");
}

try {
  for (const condition of conditions) {
    await runCase(condition, false, "document", navigation);
    await runCase(condition, true, "deferred", navigation);
    await runCase(condition, false, "notes", notes);
    await runCase(condition, true, "notes", notes);
  }
  await seedBoard();
  for (const condition of conditions) {
    await runCase(condition, false, "table", denseTable);
    await runCase(condition, true, "table", denseTable);
  }
  for (const condition of conditions) await runCase(condition, true, "live", live);
} finally {
  await browser.close();
}
if (results.some(value => value.outcome !== "correct")) process.exitCode = 1;
