import { chromium } from "./repo/client/woge-fallback-client/node_modules/playwright/index.mjs";
import { expect } from "./repo/client/woge-fallback-client/node_modules/@playwright/test/index.mjs";
import { readFile, writeFile } from "node:fs/promises";
import { performance } from "node:perf_hooks";

const [port, host, output, round, mode] = process.argv.slice(2);
const origin = `http://127.0.0.1:${port}`;
const plan = JSON.parse(await readFile(new URL("./extension-plan.json", import.meta.url), "utf8")).browser;
const browser = await chromium.launch();
const project = "/projects/woge";
const board = project + "/tasks";
const taskRoute = /\/woge-actions\/add-board-task$/;
const noteRoute = /\/woge-actions\/add-note$/;
const results = [];
const conditions = [...plan.conditions];
if (Number(round) % 2 === 0) conditions.reverse();
if (mode === "pilot") conditions.splice(1, 2);
expect.configure({ timeout: 8000 });

function observeStart() {
  globalThis.study = { patch: [], shellAtMs: null, usefulAtMs: null, css: null };
  const start = new WeakMap();
  document.addEventListener("woge:before-replace", event => start.set(event.target, performance.now()));
  document.addEventListener("woge:after-replace", event => {
    const now = performance.now();
    const prior = start.get(event.target);
    globalThis.study.patch.push({ atMs: now, eventIntervalMs: prior === undefined ? null : now - prior });
  });
  const visible = node => node?.getClientRects().length && getComputedStyle(node).visibility === "visible";
  const frame = () => {
    const data = globalThis.study;
    const heading = document.querySelector("main h1");
    if (data.shellAtMs === null && visible(heading) && heading.textContent === "Woge" &&
        visible(document.querySelector('a[href$="?view=complete"]')) &&
        document.querySelectorAll("[data-woge-region]").length === 3) {
      data.shellAtMs = performance.now();
    }
    const table = document.querySelector("main table");
    const activity = document.querySelector("main .activity-list");
    const settled = !document.querySelector(".is-loading") &&
      Array.from(document.querySelectorAll("main [data-woge-region]")).every(region => region.dataset.wogeRevision === "1");
    if (visible(table) && visible(activity) && settled &&
        table.textContent.includes("Verify the deferred browser path") &&
        activity.textContent.includes("Server adapter contract verified")) {
      data.usefulAtMs = performance.now();
    } else {
      requestAnimationFrame(frame);
    }
  };
  if (location.pathname === "/projects/woge") requestAnimationFrame(frame);
}

async function preparePage(context, condition, observe) {
  const page = await context.newPage();
  page.setDefaultTimeout(8000);
  const session = await context.newCDPSession(page);
  await session.send("Network.enable");
  await session.send("Network.setCacheDisabled", { cacheDisabled: condition.cache === "disabled" });
  if (condition.cpu > 1) {
    await session.send("Emulation.setCPUThrottlingRate", { rate: condition.cpu });
    await session.send("Network.emulateNetworkConditions", {
      offline: false,
      latency: condition.latencyMs,
      downloadThroughput: condition.downloadBytesPerSecond,
      uploadThroughput: condition.uploadBytesPerSecond,
    });
  }
  await session.send("Performance.enable");
  if (observe) await page.addInitScript(observeStart);
  return { page, session };
}

async function metrics(session) {
  return Object.fromEntries((await session.send("Performance.getMetrics")).metrics.map(
    item => [item.name, item.value]));
}

async function details(page, session, startMetrics) {
  await page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))));
  const current = await metrics(session);
  const rendererMs = Object.fromEntries(
    ["TaskDuration", "ScriptDuration", "LayoutDuration", "RecalcStyleDuration", "ScriptParsingDuration"]
      .filter(key => current[key] !== undefined && startMetrics[key] !== undefined)
      .map(key => [key, (current[key] - startMetrics[key]) * 1000]),
  );
  const timings = await page.evaluate(() => {
    const navigation = performance.getEntriesByType("navigation")[0];
    return {
      observedAtMs: performance.now(),
      firstPaintMs: performance.getEntriesByName("first-contentful-paint")[0]?.startTime,
      parseToInteractiveMs: navigation?.domInteractive,
      observation: globalThis.study,
      resources: [navigation, ...performance.getEntriesByType("resource")].filter(Boolean).map(entry => ({
        path: new URL(entry.name).pathname.replace(/\/woge-patches\/[^/]+$/, "/woge-patches/{epoch}"),
        initiator: entry.initiatorType,
        transferBytes: entry.transferSize,
        encodedBodyBytes: entry.encodedBodySize,
        decodedBodyBytes: entry.decodedBodySize,
      })),
    };
  });
  return { ...timings, rendererMs };
}

async function checkProject(page) {
  await expect(page.getByRole("heading", { name: "Woge", exact: true })).toBeVisible({timeout: 8000});
  const tasks = page.getByRole("table", { name: "Current tasks for Woge" });
  await expect(tasks).toBeVisible({timeout: 8000});
  for (const text of ["Publish the first web-first guide", "Verify the deferred browser path", "Record the architecture decision"]) {
    await expect(tasks.getByText(text, { exact: true })).toBeVisible();
  }
  for (const text of ["Standards-native CSS contract implemented", "Server adapter contract verified"]) {
    await expect(page.getByText(text, { exact: true })).toBeVisible();
  }
  await expect(page.locator(".is-loading")).toHaveCount(0);
}

async function navigation(page, session, enhanced, condition) {
  const url = origin + project + (enhanced ? "" : "?view=complete");
  if (condition.cache !== "disabled") {
    await page.goto(url);
    await checkProject(page);
  }
  const start = await metrics(session);
  const patch = enhanced ? page.waitForResponse(r => r.url().includes("/woge-patches/")) : null;
  patch?.catch(() => {});
  const response = await page.goto(url, { waitUntil: "load" });
  expect(response.status()).toBe(200);
  await checkProject(page);
  if (patch) {
    const stream = await patch;
    expect(stream.status()).toBe(200);
    expect(await stream.finished()).toBeNull();
    await expect(page.locator('[data-woge-region][data-woge-revision="1"]')).toHaveCount(3);
  }
  return {
    ...(await details(page, session, start)),
    html: (await response.headerValue("content-encoding")) ?? "identity",
    patches: patch ? (await (await patch).headerValue("content-encoding")) ?? "identity" : null,
  };
}

async function notes(page, session, enhanced, condition) {
  const route = origin + "/notes";
  await page.goto(route);
  if (condition.cache !== "disabled") await page.reload();
  const input = page.getByLabel("New note");
  const button = page.getByRole("button", { name: "Add note" });
  await input.evaluate(element => element.removeAttribute("maxlength"));
  const oversized = "😀".repeat(61);
  await input.fill(oversized);
  const invalid = page.waitForResponse(r => r.request().method() === "POST" && noteRoute.test(r.url()));
  const rejectionMetrics = await metrics(session);
  const rejectionStart = performance.now();
  await button.click();
  const rejected = await invalid;
  expect(rejected.status()).toBe(400);
  await expect(page.locator("#note-errors")).toContainText("Use at most 120 UTF-16 code units.");
  await expect(input).toHaveValue(oversized);
  if (enhanced) await expect(page.locator("#note-errors")).toBeFocused();
  await expect(page.getByRole("listitem").filter({ hasText: oversized })).toHaveCount(0);
  const rejection = await details(page, session, rejectionMetrics);
  rejection.clickToObservedMs = performance.now() - rejectionStart;
  rejection.httpStatus = rejected.status();
  const title = `Study ${round} ${condition.name} ${enhanced ? "enhanced" : "native"}`;
  await input.fill(title);
  const post = page.waitForResponse(r => r.request().method() === "POST" && noteRoute.test(r.url()));
  const submitMetrics = await metrics(session);
  const submitStart = performance.now();
  await button.click();
  const saved = await post;
  expect(saved.status()).toBe(enhanced ? 200 : 303);
  await expect(page.getByRole("listitem").filter({ hasText: title })).toHaveCount(1);
  await expect(page.locator("#note-status")).toHaveText("Note added");
  const mutation = await details(page, session, submitMetrics);
  mutation.clickToObservedMs = performance.now() - submitStart;
  mutation.httpStatus = saved.status();
  return { rejection, mutation };
}

async function runCase(condition, enhanced, name, action) {
  const settings = { viewport: { width: plan.viewport[0], height: plan.viewport[1] }, javaScriptEnabled: enhanced };
  const context = await browser.newContext(settings);
  const result = { condition: condition.name, enhanced, workload: name };
  try {
    const { page, session } = await preparePage(context, condition, enhanced);
    result.result = await action(page, session, enhanced, condition);
    result.outcome = "correct";
  } catch (error) {
    result.outcome = "error";
    result.problem = String(error);
  } finally {
    results.push(result);
    await writeFile(output, JSON.stringify({ host, round: Number(round), chromium: browser.version(), results }, null, 2) + "\n");
    await context.close();
  }
  console.log(condition.name, name, enhanced, result.outcome, result.problem ?? "");
}

try {
  for (const condition of conditions) {
    await runCase(condition, false, "document", navigation);
    await runCase(condition, true, "deferred", navigation);
    await runCase(condition, false, "notes", notes);
    await runCase(condition, true, "notes", notes);
  }
} finally {
  await browser.close();
}
if (results.some(value => value.outcome !== "correct")) process.exitCode = 1;
