#!/usr/bin/env python3
"""Bounded scheduled traffic against stand-alone Woge reference JVM processes."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
import http.client
from html.parser import HTMLParser
import json
import math
import pathlib
import os
import platform
import socket
import statistics
import struct
import subprocess
import time

HERE = pathlib.Path(__file__).resolve().parent
REPO = HERE / "repo"
SPEC = json.loads((HERE / "protocol.json").read_text())
BODY_LIMIT = 32768
SHELL = "/projects/woge"
NATIVE = SHELL + "?view=complete"
DEFERRED_TYPE = "application/vnd.woge.patch-stream; version=1"
MILLISECONDS = 1_000_000
EXPECTED = {
    "summary-heading": ('<dt>Open tasks</dt><dd>2</dd>', '<dt>Completed tasks</dt><dd>1</dd>', '<dt>Recent events</dt><dd>2</dd>'),
    "tasks-heading": ("Current tasks for Woge", "Publish the first web-first guide", "Verify the deferred browser path", "Record the architecture decision"),
    "activity-heading": ("Standards-native CSS contract implemented", "Server adapter contract verified"),
}


def expect(condition, message):
    if not condition:
        raise ValueError(message)


class ShellMetadata(HTMLParser):
    def __init__(self, rendered):
        super().__init__()
        self.epoch = None
        self.patch_url = None
        self.targets = {}
        self.feed(rendered)

    def handle_starttag(self, tag, attributes):
        attributes = dict(attributes)
        target = attributes.get("data-woge-region")
        if tag == "meta" and attributes.get("name") == "woge-page-epoch":
            self.epoch = attributes.get("content")
        if tag == "body":
            self.patch_url = attributes.get("data-woge-patch-url")
        if target:
            expect(attributes.get("data-woge-revision") == "0", "nonzero shell region revision")
            self.targets[target] = attributes.get("aria-labelledby")


def elapsed_ms(start, end):
    return round((end - start) / MILLISECONDS, 6)


def parse_frame(stream):
    header = stream.read(10)
    expect(len(header) == 10, "truncated frame header")
    kind, type_size, metadata_size, html_size = struct.unpack(">BBII", header)
    frame_size = type_size + metadata_size + html_size
    expect(0 < frame_size < BODY_LIMIT, "frame larger than bounded fixture")
    frame = stream.read(frame_size)
    expect(len(frame) == frame_size, "truncated frame body")
    metadata_end = type_size + metadata_size
    media = frame[:type_size].decode("ascii")
    return kind, media, json.loads(frame[type_size:metadata_end]), frame[metadata_end:].decode("utf-8"), 10 + frame_size


def http_get(connection, path, media, sample, name):
    connection.request("GET", path, headers={"Accept": media, "Accept-Encoding": "identity"})
    response = connection.getresponse()
    sample[name + "Status"] = response.status
    sample[name + "Encoding"] = response.getheader("Content-Encoding") or "identity"
    expect(response.status == 200, f"{name} returned HTTP {response.status}")
    supplied_type = response.getheader("Content-Type", "")
    sample[name + "ContentType"] = supplied_type
    normalize = lambda value: tuple(part.strip().lower() for part in value.split(";"))
    expected = normalize(media)
    expect(normalize(supplied_type)[:len(expected)] == expected, f"{name} unexpected content type: {supplied_type}")
    expect(sample[name + "Encoding"] == "identity", f"{name} unexpected response encoding")
    return response


def project_journey(port, planned, deadline_ms, disconnect=False, native=False):
    dispatched = time.monotonic_ns()
    sample = {"plannedNs": planned, "dispatchNs": dispatched, "outcome": "error"}
    seconds_left = (planned + deadline_ms * MILLISECONDS - dispatched) / 1_000_000_000
    connection = None
    if seconds_left <= 0:
        return dict(sample, completedNs=dispatched, outcome="dropped")
    try:
        connection = http.client.HTTPConnection("127.0.0.1", port, timeout=seconds_left)
        with http_get(connection, NATIVE if native else SHELL, "text/html", sample, "html") as response:
            body = response.read(BODY_LIMIT)
        rendered = body.decode("utf-8")
        sample["htmlBodyBytes"] = len(body)
        sample["htmlCompleteNs"] = time.monotonic_ns()
        expect(len(body) < BODY_LIMIT and "<h1>Woge</h1>" in rendered, "missing bounded Woge HTML")
        if native:
            expect("data-woge-region" not in rendered and "is-loading" not in rendered, "native page has incomplete regions")
            expect(all(text in rendered for parts in EXPECTED.values() for text in parts), "native page missing project content")
        else:
            expect('href="' + NATIVE + '"' in rendered and rendered.count('class="is-loading"') == 3,
                   "shell missing complete-page fallback or placeholders")
            metadata = ShellMetadata(rendered)
            expect(metadata.epoch and metadata.patch_url == f"{SHELL}/woge-patches/{metadata.epoch}",
                   "shell has invalid patch URL for its epoch")
            expect(len(metadata.targets) == 3 and set(metadata.targets.values()) == set(EXPECTED),
                   "shell missing declared fixture targets")
            with http_get(connection, metadata.patch_url, DEFERRED_TYPE, sample, "patch") as stream:
                expect(stream.read(5) == b"WOGE\x01", "invalid version-one preamble")
                sample["patchHeadersNs"] = time.monotonic_ns()
                sizes = 5
                seen = set()
                for number in range(1 if disconnect else 3):
                    kind, media, frame, html, size = parse_frame(stream)
                    if number == 0:
                        sample["firstPatchNs"] = time.monotonic_ns()
                    sizes += size
                    target = frame.get("target")
                    expect(kind == 1 and media == "text/html; charset=utf-8", "expected HTML patch frame")
                    expect(target in metadata.targets and target not in seen, "unexpected patch target")
                    expect(frame.get("epoch") == metadata.epoch and frame.get("operation") == "replace"
                           and frame.get("baseRevision") == 0 and frame.get("nextRevision") == 1, "invalid replacement metadata")
                    expect(all(text in html for text in EXPECTED[metadata.targets[target]]), "patch missing project content")
                    seen.add(target)
                if not disconnect:
                    kind, media, terminal, html, size = parse_frame(stream)
                    expect(kind == 2 and media == "application/json; charset=utf-8" and terminal == {"patches": 3}
                           and not html, "invalid completion frame")
                    sizes += size
                    expect(not stream.read(1), "bytes followed the completion frame")
                sample["patchBodyBytes"] = sizes
        sample["outcome"] = "disconnect-after-first" if disconnect else "correct"
    except (OSError, http.client.HTTPException, ValueError) as error:
        sample["outcome"] = "timeout" if isinstance(error, TimeoutError) else "error"
        sample["problem"] = f"{type(error).__name__}: {error}"
    finally:
        if connection is not None:
            connection.close()
        sample["completedNs"] = time.monotonic_ns()
    if sample["outcome"] == "correct" and sample["completedNs"] - planned > deadline_ms * MILLISECONDS:
        sample["outcome"] = "timeout"
    return sample


def resource_snapshot(pid, port):
    status = pathlib.Path(f"/proc/{pid}/status").read_text().splitlines()
    stat = pathlib.Path(f"/proc/{pid}/stat").read_text().split(") ", 1)[1].split()
    memory = {line.split(":")[0]: int(line.split()[1]) for line in status if line.startswith(("VmRSS:", "VmHWM:"))}
    return {
        "monotonicNs": time.monotonic_ns(),
        "cpuSeconds": (int(stat[11]) + int(stat[12])) / os.sysconf("SC_CLK_TCK"),
        "rssKiB": memory.get("VmRSS"),
        "peakRssKiB": memory.get("VmHWM"),
        "openFds": len(list(pathlib.Path(f"/proc/{pid}/fd").iterdir())),
        "establishedInbound": tcp_count(port, "01"),
    }


def tcp_count(port, state):
    return sum(
        columns[1].endswith(f":{port:04X}") and columns[3] == state
        for table in ("/proc/net/tcp", "/proc/net/tcp6")
        for line in pathlib.Path(table).read_text().splitlines()[1:]
        if (columns := line.split())
    )


@contextmanager
def server(host, artifact_directory):
    with socket.socket() as listener:
        listener.bind(("127.0.0.1", 0))
        port = listener.getsockname()[1]
    command = ["python3", str(REPO / "scripts/reference-demo.py"), "serve", host, "--port", str(port)]
    with (artifact_directory / "server.log").open("w") as logs:
        launched = time.monotonic_ns()
        process = subprocess.Popen(command, cwd=REPO, stdout=logs, stderr=subprocess.STDOUT)
        try:
            readiness_deadline = time.monotonic() + 30
            while time.monotonic() < readiness_deadline and process.poll() is None:
                ready = project_journey(port, time.monotonic_ns(), 500, native=True)
                if ready["outcome"] == "correct":
                    break
                time.sleep(0.1)
            else:
                raise RuntimeError(f"{host} did not serve the expected packaged project within 30 seconds")
            dump(artifact_directory / "startup.json", {"initialProcessReadyMs": elapsed_ms(launched, time.monotonic_ns()), "pollIntervalMs": 100, "readiness": ready})
            yield port, process.pid
        finally:
            if process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(timeout=5)
            state = {"exitCode": process.returncode, "processReaped": process.poll() is not None,
                     "listeners": tcp_count(port, "0A"), "establishedInbound": tcp_count(port, "01")}
            dump(artifact_directory / "shutdown.json", state)
            expect(state["processReaped"] and not state["listeners"] and not state["establishedInbound"],
                   f"{host} left a process or loopback listener")


def run_arrivals(port, pid, rate, duration):
    before = resource_snapshot(pid, port)
    count = rate * duration
    with ThreadPoolExecutor(max_workers=SPEC["http"]["workerLimit"]) as pool:
        futures = []
        start = time.monotonic_ns()
        for number in range(count):
            arrival = start + number * 1_000_000_000 // rate
            delay = (arrival - time.monotonic_ns()) / 1_000_000_000
            if delay > 0:
                time.sleep(delay)
            futures.append(pool.submit(project_journey, port, arrival, SPEC["http"]["requestDeadlineMs"]))
        samples = [future.result() for future in futures]
    finished = max(sample["completedNs"] for sample in samples)
    return {"plannedRate": rate, "windowSeconds": duration, "startNs": start, "endNs": finished,
            "before": before, "after": resource_snapshot(pid, port), "samples": samples}


def dump(output, data):
    output.write_text(json.dumps(data, indent=2) + "\n")


def nearest_rank(values, fraction):
    return sorted(values)[math.ceil(len(values) * fraction) - 1]


def summarize(run):
    attempts = run["samples"]
    correct = [sample for sample in attempts if sample["outcome"] == "correct"]
    outcomes = {label: sum(sample["outcome"] == label for sample in attempts)
                for label in ("correct", "dropped", "timeout", "error")}
    durations = [elapsed_ms(s["plannedNs"], s["completedNs"]) for s in correct]
    objective = SPEC["http"]["serviceObjective"]["thresholdMs"]
    window_end = run["startNs"] + run["windowSeconds"] * 1_000_000_000
    result = {"outcomes": outcomes, "scheduled": len(attempts),
              "startedPerSecondInWindow": sum(s["dispatchNs"] <= window_end and s["outcome"] != "dropped"
                                             for s in attempts) / run["windowSeconds"],
              "correctCompletionPerSecondThroughDrain": len(correct) * 1_000_000_000 / (run["endNs"] - run["startNs"]),
              "within750Ms": sum(ms <= objective for ms in durations),
              "cpuSeconds": round(run["after"]["cpuSeconds"] - run["before"]["cpuSeconds"], 3)}
    for name, values in {
        "scheduledToCompleteMs": durations,
        "dispatchToCompleteMs": [elapsed_ms(s["dispatchNs"], s["completedNs"]) for s in correct],
        "generatorQueueMs": [elapsed_ms(s["plannedNs"], s["dispatchNs"]) for s in attempts],
        "shellMs": [elapsed_ms(s["dispatchNs"], s["htmlCompleteNs"]) for s in correct],
        "firstPatchMs": [elapsed_ms(s["dispatchNs"], s["firstPatchNs"]) for s in correct],
    }.items():
        if values:
            result[name] = {"p50": round(statistics.median(values), 3), "p95": round(nearest_rank(values, .95), 3),
                            **({"p99": round(nearest_rank(values, .99), 3)} if len(values) >= 200 else {})}
    if correct:
        result["bodyBytes"] = {
            "html": sorted({sample["htmlBodyBytes"] for sample in correct}),
            "patch": sorted({sample["patchBodyBytes"] for sample in correct}),
        }
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("phase", choices=("pilot", "measured"))
    args = parser.parse_args()
    directory = HERE / args.phase
    directory.mkdir()
    summaries = []
    rounds = SPEC["rotation"] if args.phase == "measured" else [SPEC["hosts"]]
    for number, order in enumerate(rounds, 1):
        for host in order:
            output = directory / f"round-{number}-{host}"
            output.mkdir()
            with server(host, output) as (port, pid):
                warmup = SPEC["http"]["warmup"]
                dump(output / "warmup.json", run_arrivals(port, pid, warmup["ratePerSecond"], warmup["seconds"]))
                rates = SPEC["http"]["arrivalRatesPerSecond"]
                run_rates = (rates if number % 2 else rates[::-1]) if args.phase == "measured" else [SPEC["http"]["pilot"]["ratePerSecond"]]
                for rate in run_rates:
                    duration = SPEC["http"]["windowSeconds"] if args.phase == "measured" else SPEC["http"]["pilot"]["seconds"]
                    run = run_arrivals(port, pid, rate, duration)
                    dump(output / f"http-{rate}.json", run)
                    summary = {"round": number, "host": host, "rate": rate, **summarize(run)}
                    summaries.append(summary)
                    dump(directory / "summary.json", summaries)
                    print(json.dumps(summary), flush=True)
                    time.sleep(1)
                controls = {}
                for label, options in (("native", {"native": True}), ("disconnect", {"disconnect": True}), ("afterDisconnect", {})):
                    controls[label] = project_journey(port, time.monotonic_ns(), 2500, **options)
                    time.sleep(0.5)
                controls["afterDrain"] = resource_snapshot(pid, port)
                dump(output / "controls.json", controls)
                expect(controls["native"]["outcome"] == controls["afterDisconnect"]["outcome"] == "correct",
                       "complete native or post-disconnect recovery failed")
                expect(controls["disconnect"]["outcome"] == "disconnect-after-first"
                       and not controls["afterDrain"]["establishedInbound"], "disconnect control did not drain")


if __name__ == "__main__":
    main()
