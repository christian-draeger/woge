#!/usr/bin/env python3
from contextlib import closing
from hashlib import sha256
import http.client
from pathlib import Path
import re
import sys
from http_study import server, dump

PATHS = ['/assets/application.css', '/assets/application.js', '/assets/woge/index.js',
         '/assets/woge-ui/dialog.js', '/assets/absent.css']
CACHED_HEADERS = ['cache-control', 'etag', 'last-modified', 'expires', 'vary', 'age', 'content-type', 'content-length']

def request(port, path, method='GET', headers=None):
    with closing(http.client.HTTPConnection('127.0.0.1', port, timeout=8)) as conn:
        conn.request(method, path, headers={'Accept-Encoding': 'identity', **(headers or {})})
        with conn.getresponse() as response:
            body = response.read()
            return {'status': response.status, 'headers': {k: response.getheader(k) for k in CACHED_HEADERS},
                    'size': len(body), 'sha256': sha256(body).hexdigest()}, body

result = {}
for host in sys.argv[2:]:
    output = Path(sys.argv[1]) / host
    output.mkdir(parents=True)
    with server(host, output) as (port, _):
        host_result = {}
        for asset in PATHS:
            initial, _ = request(port, asset)
            cache = initial['headers']
            validators = {}
            if cache['etag']:
                validators['If-None-Match'] = cache['etag']
            if cache['last-modified']:
                validators['If-Modified-Since'] = cache['last-modified']
            host_result[asset] = {'GET': initial, 'secondGET': request(port, asset)[0],
                                  'HEAD': request(port, asset, 'HEAD')[0],
                                  'validatorsSent': validators,
                                  'conditionalGET': request(port, asset, headers=validators)[0] if validators else None,
                                  'conditionalHEAD': request(port, asset, 'HEAD', validators)[0] if validators else None,
                                  'unmatchedETagGET': request(port, asset, headers={'If-None-Match': '"unmatched-local-control"'})[0]}
        shell, body = request(port, '/projects/woge')
        patch_path = re.search(rb'data-woge-patch-url="([^\"]+)"', body).group(1).decode()
        host_result['page'] = shell
        host_result['patch'] = request(port, patch_path, headers={'Accept': 'application/vnd.woge.patch-stream; version=1'})[0]
        result[host] = host_result
    dump(Path(sys.argv[1]) / 'headers.json', result)
