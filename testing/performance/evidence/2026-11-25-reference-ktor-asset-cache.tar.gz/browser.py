#!/usr/bin/env python3
from pathlib import Path
import subprocess
import sys

from http_study import HERE, dump, run_arrivals, server

output = Path(sys.argv[1])
output.mkdir(parents=True)
for index in range(1, 4):
    block = output / f'round-{index}-ktor'
    block.mkdir()
    with server('ktor', block) as (port, pid):
        dump(block / 'warmup.json', run_arrivals(port, pid, 8, 4))
        arguments = ['node', str(HERE / 'browser-shell.mjs'), str(port), 'ktor',
                     str(block / 'browser.json'), str(index), 'shell']
        with (block / 'browser.log').open('w') as log:
            results = subprocess.run(arguments, stdout=log, stderr=subprocess.STDOUT, timeout=220)
        print(index, results.returncode, flush=True)
        if results.returncode:
            raise SystemExit(results.returncode)
