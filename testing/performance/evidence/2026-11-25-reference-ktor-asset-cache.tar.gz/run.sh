#!/usr/bin/env bash
set -euo pipefail
study=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
: "${WOGE_STUDY_REPO:?Set WOGE_STUDY_REPO to the archived checkout with installed Node dependencies and all three built packages}"
: "${WOGE_STUDY_LINUX_JAVA_HOME:?Set WOGE_STUDY_LINUX_JAVA_HOME to Linux arm64 Temurin 21.0.12.1+1}"
docker run --rm --platform linux/arm64 --network none --cpus 2 --memory 2g --shm-size 512m \
  --mount "type=bind,source=$study,target=/study" \
  --mount "type=bind,source=$WOGE_STUDY_REPO,target=/study/repo,readonly" \
  --mount "type=bind,source=$WOGE_STUDY_LINUX_JAVA_HOME,target=/jvm,readonly" \
  --env JAVA_HOME=/jvm \
  --env 'JAVA_TOOL_OPTIONS=-Xms128m -Xmx512m -XX:+UseG1GC -XX:ActiveProcessorCount=2' \
  mcr.microsoft.com/playwright:v1.62.1-noble@sha256:dcc5531e97840b9b5e794f2814476b21571c5124a3fca2267d73041f56e7580e \
  bash -ec 'export PATH="$JAVA_HOME/bin:$PATH"; cd /study; exec "$@"' study "$@"
