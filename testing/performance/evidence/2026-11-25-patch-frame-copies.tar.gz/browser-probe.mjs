import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import { randomUUID } from "node:crypto";
import { writeFileSync } from "node:fs";
import { createRequire } from "node:module";
import { resolve } from "node:path";
import { setTimeout } from "node:timers/promises";

const [repo, resultsPath, before, after] = process.argv.slice(2);
assert(repo && resultsPath && before && after);
const require = createRequire(resolve(repo, "client/woge-fallback-client/package.json"));
const { chromium } = require("playwright");
const docker = (...args) => execFileSync("docker", args, {encoding: "utf8", timeout: 30000}).trim();
const plan = [["spring-woge", "before"], ["spring-woge", "after"], ["ktor-woge", "after"], ["ktor-woge", "before"],
  ["spring-woge", "after"], ["spring-woge", "before"], ["ktor-woge", "before"], ["ktor-woge", "after"]];
const browser = await chromium.launch();
const results = {chromium: browser.version(), node: process.version, plan, runs: []};
try {
  for (const [mode, variant] of plan) {
    const image = variant === "before" ? before : after;
    const name = `woge-copy-browser-${randomUUID().slice(0, 10)}`;
    const run = {mode, variant, warmup: [], measured: []};
    results.runs.push(run);
    docker("run", "--detach", "--rm", "--name", name, "--cpus", "2", "--memory", "768m",
      "--pids-limit", "256", "--read-only", "--tmpfs", "/tmp:rw,nosuid,size=64m", "-p", "127.0.0.1::8080",
      "-e", `BENCH_MODE=${mode}`, "-e", "JAVA_OPTS=-Xms128m -Xmx512m -XX:+UseG1GC", image);
    let context;
    try {
      const origin = `http://127.0.0.1:${docker("port", name, "8080/tcp").split(":").at(-1)}`;
      const deadline = performance.now() + 20000;
      let ready = false;
      while (!ready && performance.now() < deadline) {
        try { ready = (await fetch(origin)).ok; } catch { /* Listener is starting. */ }
        if (!ready) await setTimeout(150);
      }
      assert(ready);
      context = await browser.newContext();
      const page = await context.newPage();
      const errors = [];
      page.on("pageerror", error => errors.push(error.message));
      await page.goto(origin);
      const row = page.locator('li[data-todo-id="1"]');
      for (let iteration = 0; iteration < 12; iteration++) {
        const completed = iteration % 2 === 0;
        const prior = completed ? "Complete" : "Mark active";
        const next = completed ? "Mark active" : "Complete";
        await page.evaluate(({prior, next}) => {
          window.frameCopyTiming = null;
          let started;
          function click(event) {
            if (event.target.closest('li[data-todo-id="1"] button')?.textContent.trim() === prior) started = performance.now();
          }
          document.addEventListener("click", click, true);
          const observer = new MutationObserver(() => {
            const stateChanged = document.querySelector('li[data-todo-id="1"] button')?.textContent.trim() === next;
            if (started !== undefined && stateChanged && document.querySelector("#todo-status")?.textContent.includes("Todo updated.")) {
              window.frameCopyTiming = performance.now() - started;
              document.removeEventListener("click", click, true);
              observer.disconnect();
            }
          });
          observer.observe(document.body, {subtree: true, childList: true, characterData: true});
        }, {prior, next});
        const response = page.waitForResponse(item => item.request().method() === "POST" && item.url().endsWith("/woge-actions/toggle-todo"));
        await row.getByRole("button", {name: prior, exact: true}).click();
        assert.equal((await response).status(), 200);
        await page.waitForFunction(() => window.frameCopyTiming !== null);
        const millis = await page.evaluate(() => window.frameCopyTiming);
        (iteration < 2 ? run.warmup : run.measured).push(millis);
        assert.equal(await page.locator("li[data-todo-id]").count(), 10);
      }
      assert.deepEqual(errors, []);
    } catch (error) {
      run.failure = error.message;
      throw error;
    } finally {
      await context?.close();
      docker("stop", "--timeout", "10", name);
      writeFileSync(resultsPath, JSON.stringify(results, null, 2) + "\n");
    }
    console.log(mode, variant, run.measured.length, "visible outcomes");
  }
} finally {
  await browser.close();
}
