plugins {
    kotlin("jvm") version "2.4.10"
    application
}

repositories {
    maven(uri(providers.gradleProperty("wogeRepository").get()))
    mavenCentral()
}

kotlin.jvmToolchain(21)

dependencies {
    implementation("dev.woge:woge-server-runtime:0.1.0-SNAPSHOT")
}

application.mainClass = "FrameAllocationKt"
