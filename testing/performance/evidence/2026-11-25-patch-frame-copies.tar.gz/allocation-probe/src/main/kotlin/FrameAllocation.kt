import com.sun.management.ThreadMXBean
import dev.woge.host.PageIdentity
import dev.woge.host.PageRegion
import dev.woge.host.RenderIdentitySecret
import dev.woge.host.actionRegionUpdates
import dev.woge.html.HtmlWriter
import dev.woge.html.applicationUrl
import dev.woge.protocol.PageEpoch
import dev.woge.protocol.PatchStreamV1
import dev.woge.runtime.encodeActionPatchStream
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.runBlocking
import java.lang.management.ManagementFactory
import java.security.MessageDigest
import java.util.HexFormat

fun main() = runBlocking {
    val thread = Thread.currentThread().threadId()
    val bean = ManagementFactory.getThreadMXBean() as ThreadMXBean
    check(bean.isThreadAllocatedMemorySupported)
    bean.isThreadAllocatedMemoryEnabled = true
    val identity = PageIdentity(PageEpoch.of("frame-copy-sample"), RenderIdentitySecret.of(ByteArray(32)))
    fun region(name: String) = object : PageRegion<String>(name) {
        override fun render(writer: HtmlWriter, input: String) = writer.text(input)
    }.target(identity)
    val prepared = actionRegionUpdates(applicationUrl("/")) {
        replace(region("board"), "Todo & Kotlin • 田\n".repeat(432))
        replace(region("entry"), "A focused form")
        replace(region("status"), "Saved")
    }
    val expected = PatchStreamV1.encode(prepared.patches)
    val chunks = prepared.encodeActionPatchStream().toList()
    val wire = chunks.fold(ByteArray(0)) { bytes, chunk -> bytes + chunk.bytes }
    check(wire.contentEquals(expected) && chunks.size == 5 && chunks.last().terminal)
    var sink = 0L
    suspend fun encode() {
        prepared.encodeActionPatchStream().collect { chunk ->
            sink += chunk.bytes.size + chunk.bytes.first()
        }
    }
    repeat(2_000) { encode() }
    println("wire=${wire.size} chunks=${chunks.map { it.bytes.size }} sha256=${HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(wire))}")
    repeat(5) { round ->
        val started = System.nanoTime()
        val allocated = bean.getThreadAllocatedBytes(thread)
        repeat(1_200) { encode() }
        val bytes = bean.getThreadAllocatedBytes(thread) - allocated
        val nanos = System.nanoTime() - started
        check(Thread.currentThread().threadId() == thread)
        println("round=${round + 1} bytes=$bytes nanos=$nanos count=1200")
    }
    println("sink=$sink")
}
