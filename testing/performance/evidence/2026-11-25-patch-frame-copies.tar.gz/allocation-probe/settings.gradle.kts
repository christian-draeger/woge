rootProject.name = "woge-patch-frame-copy-probe"
