import { defineConfig } from "@playwright/test";

const root = process.cwd();
const servers = [
  ["env PORT=18741 WOGE_STUDY_STATIC=./woge-content/static ./woge-content/build/install/woge-content-study/bin/woge-content-study", "http://127.0.0.1:18741/tasks.html"],
  ["env HOST=127.0.0.1 PORT=18742 node astro/dist/server/entry.mjs", "http://127.0.0.1:18742/tasks.html"],
  ["env PORT=18743 ./repo/spikes/backlog-chart/build/install/woge-backlog-chart-spike/bin/woge-backlog-chart-spike", "http://127.0.0.1:18743/backlog"],
  ["python3 -m http.server 18744 --bind 127.0.0.1 --directory svelte/build", "http://127.0.0.1:18744/backlog/"],
  ["python3 -m http.server 18745 --bind 127.0.0.1 --directory woge-content/static", "http://127.0.0.1:18745/tasks.html"],
  ["python3 -m http.server 18746 --bind 127.0.0.1 --directory astro/dist/client", "http://127.0.0.1:18746/tasks.html"],
];

export default defineConfig({
  testDir: "./checks", workers: 1, retries: 0, timeout: 120000,
  use: { browserName: "chromium", viewport: { width: 900, height: 420 } },
  webServer: servers.map(([command, url]) => ({ command, url, cwd: root, stdout: "pipe", stderr: "pipe", timeout: 15000 })),
  reporter: [["line"], ["json", { outputFile: "browser-result.json" }]],
});
