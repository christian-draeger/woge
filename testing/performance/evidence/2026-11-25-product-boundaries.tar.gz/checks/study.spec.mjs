import { createHash } from "node:crypto";
import { readFile, readdir, writeFile } from "node:fs/promises";
import { expect, test } from "@playwright/test";

const content = [
  { name: "Woge+Ktor", origin: "http://127.0.0.1:18741", exported: "http://127.0.0.1:18745" },
  { name: "Astro+Node", origin: "http://127.0.0.1:18742", exported: "http://127.0.0.1:18746" },
];
const charts = [
  { name: "Woge+Chart.js", origin: "http://127.0.0.1:18743", path: "/backlog" },
  { name: "SvelteKit+Chart.js", origin: "http://127.0.0.1:18744", path: "/backlog/" },
];
const article = "/tasks.html";
const normalize = text => text.replace(/\s+/g, " ").trim();
const checksum = content => createHash("sha256").update(content).digest("hex");

function responseInfo(response) {
  return { status: response.status(), cacheControl: response.headers()["cache-control"] ?? null,
    contentType: response.headers()["content-type"] ?? null };
}

async function resources(page) {
  return page.evaluate(() => [performance.getEntriesByType("navigation")[0], ...performance.getEntriesByType("resource")]
    .filter(Boolean).map(x => ({
      path: new URL(x.name).pathname, initiator: x.initiatorType, bytes: x.decodedBodySize,
      transferBytes: x.transferSize, encodedBytes: x.encodedBodySize, responseEndMs: x.responseEnd,
    })));
}

async function snapshotArticle(page, url) {
  const response = await page.goto(url);
  expect(response?.status()).toBe(200);
  await expect(page.getByRole("heading", { name: "Everyday Woge tasks", level: 1 })).toBeVisible();
  await expect(page.getByRole("link", { name: "Change reading preferences" })).toBeVisible();
  const snippet = await readFile("repo/examples/complexity-gradient/src/main/kotlin/dev/woge/examples/gradient/t01staticpage/StaticPage.kt", "utf8");
  expect(normalize(await page.locator("article pre").innerText())).toBe(normalize(snippet));
  const body = await response.body();
  return {
    title: await page.title(), description: await page.locator('meta[name="description"]').getAttribute("content"),
    article: normalize(await page.locator("article").innerText()),
    headings: await page.locator("article h2").evaluateAll(elements => elements.map(heading => [heading.id, heading.textContent])),
    bodyBytes: body.length, sha256: checksum(body), http: responseInfo(response), resources: await resources(page),
  };
}

test("content export and per-browser topic action work in both approaches", async ({ browser }) => {
  const rows = [];
  for (const side of content) {
    const row = { framework: side.name, browser: browser.version() };
    rows.push(row);
    const context = await browser.newContext({ javaScriptEnabled: false });
    const page = await context.newPage();
    try {
      row.export = await snapshotArticle(page, side.exported + article);
      row.before = await snapshotArticle(page, side.origin + article);
      expect(row.before.sha256).toBe(row.export.sha256);
      await page.getByRole("link", { name: "Change reading preferences" }).click();
      await expect(page.locator("[data-current-topic]")).toHaveText("Topic: Overview");
      row.preferenceBefore = responseInfo(await page.reload());
      expect(row.preferenceBefore.cacheControl).toContain("no-store");
      await page.getByLabel("Reading topic").selectOption("delivery");
      const posted = page.waitForResponse(response => response.request().method() === "POST");
      await page.getByRole("button", { name: "Save topic" }).click();
      row.post = responseInfo(await posted);
      expect(row.post.status).toBe(303);
      await expect(page.locator("[data-current-topic]")).toHaveText("Topic: Delivery");
      await page.reload();
      await expect(page.locator("[data-current-topic]")).toHaveText("Topic: Delivery");
      await page.getByLabel("Reading topic").evaluate(select => {
        select.add(new Option("Unsupported", "unsupported"));
        select.value = "unsupported";
      });
      const invalid = page.waitForResponse(response => response.request().method() === "POST");
      await page.getByRole("button", { name: "Save topic" }).click();
      row.invalidStatus = (await invalid).status();
      expect(row.invalidStatus).toBe(400);
      await expect(page.getByRole("alert")).toHaveText("Choose a listed topic.");
      await page.goto(side.origin + "/preferences");
      await expect(page.locator("[data-current-topic]")).toHaveText("Topic: Delivery");
      row.after = await snapshotArticle(page, side.origin + article);
      expect(row.before.sha256).toBe(row.after.sha256);
      row.cookie = (await context.cookies()).filter(cookie => cookie.name === "study-topic");
      expect(row.cookie).toHaveLength(1);
      expect(row.cookie[0]).toMatchObject({ value: "delivery", httpOnly: true, sameSite: "Lax" });
      const other = await browser.newContext({ javaScriptEnabled: true });
      const dynamic = await other.newPage();
      try {
        const result = dynamic.waitForResponse(response => /\/preferences\/topic|\/_server-islands\//.test(response.url()));
        await dynamic.goto(side.origin + article);
        row.anonymousDynamic = responseInfo(await result);
        await expect(dynamic.locator("[data-current-topic]")).toHaveText("Topic: Overview");
        await other.addCookies(row.cookie);
        const personalized = dynamic.waitForResponse(response => /\/preferences\/topic|\/_server-islands\//.test(response.url()));
        await dynamic.reload();
        row.personalizedDynamic = responseInfo(await personalized);
        await expect(dynamic.locator("[data-current-topic]")).toHaveText("Topic: Delivery");
        expect(row.personalizedDynamic.cacheControl).toContain("no-store");
        row.browserResources = await resources(dynamic);
      } finally {
        await other.close();
      }
    } finally {
      await context.close();
      await writeFile("content-raw.json", JSON.stringify(rows, null, 2) + "\n");
    }
  }
  expect(rows[1].export.article).toBe(rows[0].export.article);
  expect(rows[1].export.title).toBe(rows[0].export.title);
  expect(rows[1].export.description).toBe(rows[0].export.description);
  expect(rows[1].export.headings).toEqual(rows[0].export.headings);
});

const chunkDirectory = "svelte/build/_app/immutable/chunks";
const chunkNames = await readdir(chunkDirectory);
const chartFlags = await Promise.all(chunkNames.map(async name =>
  (await readFile(`${chunkDirectory}/${name}`, "utf8")).includes("Invalid backlog chart data")));
const svelteChart = chunkNames.filter((_, index) => chartFlags[index]);
if (svelteChart.length !== 1) throw new Error("Svelte chart chunk could not be identified");
const chartRequest = ({ path }) => path === "/assets/chart/backlog.js" || path.endsWith("/" + svelteChart[0]);
const chartData = Array.from({ length: 14 }, (_, index) => [
  `2026-06-${String(index + 1).padStart(2, "0")}`,
  String(17 + (index * 2) % 19), String(12 + (index * 3 + 2) % 15),
]);
async function canvasImage(page) {
  return checksum(await page.locator("canvas").evaluate(canvas => canvas.toDataURL()));
}
async function keyboardToFrame(page, button) {
  await button.focus();
  await page.evaluate(() => {
    globalThis.observedClickFrame = null;
    document.addEventListener("click", () => {
      const start = performance.now();
      requestAnimationFrame(() => requestAnimationFrame(() => {
        globalThis.observedClickFrame = performance.now() - start;
      }));
    }, { capture: true, once: true });
  });
  await page.keyboard.press("Space");
  await page.waitForFunction(() => globalThis.observedClickFrame !== null);
  return page.evaluate(() => globalThis.observedClickFrame);
}

test("both report fixtures preserve native rows and defer the same local chart work", async ({ browser }) => {
  const rows = [];
  for (const side of charts) {
    const context = await browser.newContext({ javaScriptEnabled: false });
    try {
      const page = await context.newPage();
      const response = await page.goto(side.origin + side.path);
      expect(response.status()).toBe(200);
      await expect(page.getByRole("table", { name: "Open orders by day, June 1–14" })).toBeVisible();
      expect(await page.locator("tbody tr").evaluateAll(tr => tr.map(row => [...row.cells].map(cell => cell.textContent.trim())))).toEqual(chartData);
      await expect(page.locator("[data-chart-controls]")).toBeHidden();
    } finally {
      await context.close();
    }
  }
  for (let round = 1; round <= 3; round++) {
    const order = round % 2 === 1 ? charts : [...charts].reverse();
    for (const side of order) {
      const row = { framework: side.name, round, browser: browser.version(), outcome: "incomplete" };
      rows.push(row);
      const context = await browser.newContext({ viewport: { width: 900, height: 420 } });
      try {
        const page = await context.newPage();
        const requests = [];
        page.on("request", request => requests.push(new URL(request.url()).pathname));
        const response = await page.goto(side.origin + side.path, { waitUntil: "networkidle" });
        expect(response.status()).toBe(200);
        row.initial = await resources(page);
        expect(row.initial.filter(chartRequest)).toHaveLength(0);
        const began = performance.now();
        await page.getByRole("heading", { name: "Backlog trend" }).scrollIntoViewIfNeeded();
        await expect(page.getByRole("img", { name: "Packing and dispatch backlog by day" })).toBeVisible();
        row.scrollToReadyMs = performance.now() - began;
        await page.waitForLoadState("networkidle");
        row.ready = await resources(page);
        expect(row.ready.filter(chartRequest)).toHaveLength(1);
        const atReady = requests.length;
        const initial = await canvasImage(page);
        const lastFour = page.getByRole("button", { name: "Show last four days" });
        row.latestKeyboardToFrameMs = await keyboardToFrame(page, lastFour);
        await expect(lastFour).toHaveAttribute("aria-pressed", "true");
        const changed = await canvasImage(page);
        expect(changed).not.toBe(initial);
        const packing = page.getByRole("button", { name: "Show packing orders" });
        row.packingKeyboardToFrameMs = await keyboardToFrame(page, packing);
        await expect(packing).toHaveAttribute("aria-pressed", "false");
        expect(await canvasImage(page)).not.toBe(changed);
        expect(requests).toHaveLength(atReady);
        row.outcome = "correct";
      } finally {
        await context.close();
        await writeFile("chart-raw.json", JSON.stringify(rows, null, 2) + "\n");
      }
    }
  }
});
