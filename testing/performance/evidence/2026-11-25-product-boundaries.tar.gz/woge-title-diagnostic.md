# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: study.spec.mjs >> content export and per-browser topic action work in both approaches
- Location: checks/study.spec.mjs:46:1

# Error details

```
Error: expect(locator).toHaveText(expected) failed

Locator: locator('[data-current-topic]')
Expected: "Topic: Overview"
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toHaveText" with timeout 5000ms
  - waiting for locator('[data-current-topic]')

```

```yaml
- text: HTML element 'title' requires a context-specific API
```

# Test source

```ts
  1   | import { createHash } from "node:crypto";
  2   | import { readFile, readdir, writeFile } from "node:fs/promises";
  3   | import { expect, test } from "@playwright/test";
  4   | 
  5   | const content = [
  6   |   { name: "Woge+Ktor", origin: "http://127.0.0.1:18741", exported: "http://127.0.0.1:18745" },
  7   |   { name: "Astro+Node", origin: "http://127.0.0.1:18742", exported: "http://127.0.0.1:18746" },
  8   | ];
  9   | const charts = [
  10  |   { name: "Woge+Chart.js", origin: "http://127.0.0.1:18743", path: "/backlog" },
  11  |   { name: "SvelteKit+Chart.js", origin: "http://127.0.0.1:18744", path: "/backlog/" },
  12  | ];
  13  | const article = "/tasks.html";
  14  | const normalize = text => text.replace(/\s+/g, " ").trim();
  15  | const checksum = content => createHash("sha256").update(content).digest("hex");
  16  | 
  17  | function responseInfo(response) {
  18  |   return { status: response.status(), cacheControl: response.headers()["cache-control"] ?? null,
  19  |     contentType: response.headers()["content-type"] ?? null };
  20  | }
  21  | 
  22  | async function resources(page) {
  23  |   return page.evaluate(() => [performance.getEntriesByType("navigation")[0], ...performance.getEntriesByType("resource")]
  24  |     .filter(Boolean).map(x => ({
  25  |       path: new URL(x.name).pathname, initiator: x.initiatorType, bytes: x.decodedBodySize,
  26  |       transferBytes: x.transferSize, encodedBytes: x.encodedBodySize, responseEndMs: x.responseEnd,
  27  |     })));
  28  | }
  29  | 
  30  | async function snapshotArticle(page, url) {
  31  |   const response = await page.goto(url);
  32  |   expect(response?.status()).toBe(200);
  33  |   await expect(page.getByRole("heading", { name: "Everyday Woge tasks", level: 1 })).toBeVisible();
  34  |   await expect(page.getByRole("link", { name: "Change reading preferences" })).toBeVisible();
  35  |   const snippet = await readFile("repo/examples/complexity-gradient/src/main/kotlin/dev/woge/examples/gradient/t01staticpage/StaticPage.kt", "utf8");
  36  |   expect(normalize(await page.locator("article pre").innerText())).toBe(normalize(snippet));
  37  |   const body = await response.body();
  38  |   return {
  39  |     title: await page.title(), description: await page.locator('meta[name="description"]').getAttribute("content"),
  40  |     article: normalize(await page.locator("article").innerText()),
  41  |     headings: await page.locator("article h2").evaluateAll(elements => elements.map(heading => [heading.id, heading.textContent])),
  42  |     bodyBytes: body.length, sha256: checksum(body), http: responseInfo(response), resources: await resources(page),
  43  |   };
  44  | }
  45  | 
  46  | test("content export and per-browser topic action work in both approaches", async ({ browser }) => {
  47  |   const rows = [];
  48  |   for (const side of content) {
  49  |     const row = { framework: side.name, browser: browser.version() };
  50  |     rows.push(row);
  51  |     const context = await browser.newContext({ javaScriptEnabled: false });
  52  |     const page = await context.newPage();
  53  |     try {
  54  |       row.export = await snapshotArticle(page, side.exported + article);
  55  |       row.before = await snapshotArticle(page, side.origin + article);
  56  |       expect(row.before.sha256).toBe(row.export.sha256);
  57  |       await page.getByRole("link", { name: "Change reading preferences" }).click();
> 58  |       await expect(page.locator("[data-current-topic]")).toHaveText("Topic: Overview");
      |                                                          ^ Error: expect(locator).toHaveText(expected) failed
  59  |       row.preferenceBefore = responseInfo(await page.reload());
  60  |       expect(row.preferenceBefore.cacheControl).toContain("no-store");
  61  |       await page.getByLabel("Reading topic").selectOption("delivery");
  62  |       const posted = page.waitForResponse(response => response.request().method() === "POST");
  63  |       await page.getByRole("button", { name: "Save topic" }).click();
  64  |       row.post = responseInfo(await posted);
  65  |       expect(row.post.status).toBe(303);
  66  |       await expect(page.locator("[data-current-topic]")).toHaveText("Topic: Delivery");
  67  |       await page.reload();
  68  |       await expect(page.locator("[data-current-topic]")).toHaveText("Topic: Delivery");
  69  |       row.after = await snapshotArticle(page, side.origin + article);
  70  |       expect(row.before.sha256).toBe(row.after.sha256);
  71  |       row.cookie = (await context.cookies()).filter(cookie => cookie.name === "study-topic");
  72  |       expect(row.cookie).toHaveLength(1);
  73  |       expect(row.cookie[0]).toMatchObject({ value: "delivery", httpOnly: true, sameSite: "Lax" });
  74  |       const other = await browser.newContext({ javaScriptEnabled: true });
  75  |       const dynamic = await other.newPage();
  76  |       try {
  77  |         const result = dynamic.waitForResponse(response => /\/preferences\/topic|\/_server-islands\//.test(response.url()));
  78  |         await dynamic.goto(side.origin + article);
  79  |         row.anonymousDynamic = responseInfo(await result);
  80  |         await expect(dynamic.locator("[data-current-topic]")).toHaveText("Topic: Overview");
  81  |         await other.addCookies(row.cookie);
  82  |         const personalized = dynamic.waitForResponse(response => /\/preferences\/topic|\/_server-islands\//.test(response.url()));
  83  |         await dynamic.reload();
  84  |         row.personalizedDynamic = responseInfo(await personalized);
  85  |         await expect(dynamic.locator("[data-current-topic]")).toHaveText("Topic: Delivery");
  86  |         expect(row.personalizedDynamic.cacheControl).toContain("no-store");
  87  |         row.browserResources = await resources(dynamic);
  88  |       } finally {
  89  |         await other.close();
  90  |       }
  91  |     } finally {
  92  |       await context.close();
  93  |       await writeFile("content-raw.json", JSON.stringify(rows, null, 2) + "\n");
  94  |     }
  95  |   }
  96  |   expect(rows[1].export.article).toBe(rows[0].export.article);
  97  |   expect(rows[1].export.title).toBe(rows[0].export.title);
  98  |   expect(rows[1].export.description).toBe(rows[0].export.description);
  99  |   expect(rows[1].export.headings).toEqual(rows[0].export.headings);
  100 | });
  101 | 
  102 | const chunkDirectory = "svelte/build/_app/immutable/chunks";
  103 | const chunkNames = await readdir(chunkDirectory);
  104 | const chartFlags = await Promise.all(chunkNames.map(async name =>
  105 |   (await readFile(`${chunkDirectory}/${name}`, "utf8")).includes("Invalid backlog chart data")));
  106 | const svelteChart = chunkNames.filter((_, index) => chartFlags[index]);
  107 | if (svelteChart.length !== 1) throw new Error("Svelte chart chunk could not be identified");
  108 | const chartRequest = ({ path }) => path === "/assets/chart/backlog.js" || path.endsWith("/" + svelteChart[0]);
  109 | const chartData = Array.from({ length: 14 }, (_, index) => [
  110 |   `2026-06-${String(index + 1).padStart(2, "0")}`,
  111 |   String(17 + (index * 2) % 19), String(12 + (index * 3 + 2) % 15),
  112 | ]);
  113 | async function canvasImage(page) {
  114 |   return checksum(await page.locator("canvas").evaluate(canvas => canvas.toDataURL()));
  115 | }
  116 | async function keyboardToFrame(page, button) {
  117 |   await button.focus();
  118 |   await page.evaluate(() => {
  119 |     globalThis.observedClickFrame = null;
  120 |     document.addEventListener("click", () => {
  121 |       const start = performance.now();
  122 |       requestAnimationFrame(() => requestAnimationFrame(() => {
  123 |         globalThis.observedClickFrame = performance.now() - start;
  124 |       }));
  125 |     }, { capture: true, once: true });
  126 |   });
  127 |   await page.keyboard.press("Space");
  128 |   await page.waitForFunction(() => globalThis.observedClickFrame !== null);
  129 |   return page.evaluate(() => globalThis.observedClickFrame);
  130 | }
  131 | 
  132 | test("both report fixtures preserve native rows and defer the same local chart work", async ({ browser }) => {
  133 |   const rows = [];
  134 |   for (const side of charts) {
  135 |     const context = await browser.newContext({ javaScriptEnabled: false });
  136 |     try {
  137 |       const page = await context.newPage();
  138 |       const response = await page.goto(side.origin + side.path);
  139 |       expect(response.status()).toBe(200);
  140 |       await expect(page.getByRole("table", { name: "Open orders by day, June 1–14" })).toBeVisible();
  141 |       expect(await page.locator("tbody tr").evaluateAll(tr => tr.map(row => [...row.cells].map(cell => cell.textContent.trim())))).toEqual(chartData);
  142 |       await expect(page.locator("[data-chart-controls]")).toBeHidden();
  143 |     } finally {
  144 |       await context.close();
  145 |     }
  146 |   }
  147 |   for (let round = 1; round <= 3; round++) {
  148 |     const order = round % 2 === 1 ? charts : [...charts].reverse();
  149 |     for (const side of order) {
  150 |       const row = { framework: side.name, round, browser: browser.version(), outcome: "incomplete" };
  151 |       rows.push(row);
  152 |       const context = await browser.newContext({ viewport: { width: 900, height: 420 } });
  153 |       try {
  154 |         const page = await context.newPage();
  155 |         const requests = [];
  156 |         page.on("request", request => requests.push(new URL(request.url()).pathname));
  157 |         const response = await page.goto(side.origin + side.path, { waitUntil: "networkidle" });
  158 |         expect(response.status()).toBe(200);
```