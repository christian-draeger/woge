<script>
  import { onMount } from "svelte";

  const days = Array.from({ length: 14 }, (_, index) => [
    `2026-06-${String(index + 1).padStart(2, "0")}`,
    17 + (index * 2) % 19,
    12 + (index * 3 + 2) % 15,
  ]);
  const field = (index) => days.map(row => row[index]).join(",");
  const props = { days: field(0), packing: field(1), dispatch: field(2) };
  let chartRoot;

  onMount(() => {
    const controller = new AbortController();
    let widget;
    const observer = new IntersectionObserver(async ([entry]) => {
      if (!entry.isIntersecting) return;
      observer.disconnect();
      try {
        const { mount } = await import("../../lib/chart.js");
        if (!controller.signal.aborted) widget = mount(chartRoot, props, { signal: controller.signal, propsVersion: 1 });
      } catch {
        // The exact daily table remains available when this optional module fails.
      }
    });
    observer.observe(chartRoot);
    return () => {
      observer.disconnect();
      controller.abort();
      widget?.dispose();
    };
  });
</script>

<svelte:head>
  <title>Warehouse backlog</title>
  <link rel="stylesheet" href="/assets/site.css" />
</svelte:head>
<main>
  <h1>Warehouse backlog</h1>
  <p role="status">Showing backlog for June 1–14.</p>
  <section id="backlog-panel">
    <table id="daily-backlog">
      <caption>Open orders by day, June 1–14</caption>
      <thead><tr><th scope="col">Day</th><th scope="col">Packing</th><th scope="col">Dispatch</th></tr></thead>
      <tbody>
        {#each days as [day, packing, dispatch] (day)}
          <tr><th scope="row">{day}</th><td>{packing}</td><td>{dispatch}</td></tr>
        {/each}
      </tbody>
    </table>
    <div bind:this={chartRoot}>
      <h2>Backlog trend</h2>
      <p><a href="#daily-backlog">Read the daily totals</a></p>
      <div hidden data-chart-controls>
        <button type="button" aria-pressed="true" data-packing>Show packing orders</button>
        <button type="button" aria-pressed="false" data-latest>Show last four days</button>
        <div role="img" aria-label="Packing and dispatch backlog by day" aria-describedby="backlog-chart-description">
          <canvas width="640" height="260" aria-hidden="true"></canvas>
        </div>
        <p id="backlog-chart-description">Packing has a solid line and dispatch a dashed line. Daily counts are in the table.</p>
      </div>
    </div>
  </section>
</main>
