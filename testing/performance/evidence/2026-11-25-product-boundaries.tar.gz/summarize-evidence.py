#!/usr/bin/env python3
"""Recalculate the scoped matched-case summaries from the raw browser records."""
import json
from pathlib import Path
from statistics import median

here = Path(__file__).resolve().parent


def read(name):
    return json.loads((here / name).read_text())


browser = read("browser-result.json")
content = read("content-raw.json")
charts = read("chart-raw.json")
assert browser["stats"]["expected"] == 2 and browser["stats"]["unexpected"] == 0
assert len(content) == 2 and len(charts) == 6
assert all(row["outcome"] == "correct" for row in charts)
assert content[0]["export"]["article"] == content[1]["export"]["article"]
assert content[0]["export"]["headings"] == content[1]["export"]["headings"]

summary = {"article": {}, "chart": {}}
for row in content:
    assert row["before"]["sha256"] == row["after"]["sha256"] == row["export"]["sha256"]
    assert row["post"]["status"] == 303 and row["invalidStatus"] == 400
    assert "no-store" in row["personalizedDynamic"]["cacheControl"]
    summary["article"][row["framework"]] = {
        "liveHtmlBytes": row["before"]["bodyBytes"],
        "personalizedArticleTotalBodyBytes": sum(asset["bytes"] for asset in row["browserResources"]),
        "articleCacheControl": row["before"]["http"]["cacheControl"],
        "topicCacheControl": row["personalizedDynamic"]["cacheControl"],
    }
for framework in sorted({row["framework"] for row in charts}):
    selected = [row for row in charts if row["framework"] == framework]
    assert {row["round"] for row in selected} == {1, 2, 3}
    startup = {sum(asset["bytes"] for asset in row["initial"] if asset["path"].endswith(".js")) for row in selected}
    before = {sum(asset["bytes"] for asset in row["initial"]) for row in selected}
    after = {sum(asset["bytes"] for asset in row["ready"]) for row in selected}
    assert len(startup) == len(before) == len(after) == 1
    summary["chart"][framework] = {
        "startupJsBytes": startup.pop(),
        "incrementalChartJsBytes": next(iter(after)) - before.pop(),
        "bodyBytesThroughChart": after.pop(),
        "descriptiveMediansMs": {label: round(median(row[label] for row in selected), 1) for label in [
            "scrollToReadyMs", "latestKeyboardToFrameMs", "packingKeyboardToFrameMs"]},
    }
(here / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
