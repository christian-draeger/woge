# Reproduce the content and local chart comparisons

The recorded run used macOS arm64, JDK 21.0.6, Node 26.3.0, Gradle 8.14.4 and Chromium
151.0.7922.34 through Playwright 1.62.1. All listeners were on loopback. No network shaping or
CPU throttling was enabled. The three chart rounds alternated host order and used fresh browser
contexts. The browser's Resource Timing API supplies decoded HTML, CSS and JS body bytes.
The Chromium clock also records descriptive scroll and interaction intervals.

Create a clean scratch directory, unpack this archive and check out Woge as `repo` at
`b2b15200b92e63e6c2058df6ffc58bc049062ff2`. Obtain the fixed Woge beta pilot kit from #50
and unpack it under `pilot`. Set `PILOT_REPOSITORY` to the kit's `repository` directory.
Use the exact #340 commit `1741e20f9df2a4221fb274df8f6a8ad15d54dfbb`
to copy `spikes/backlog-chart` into the scratch checkout. Keep the chart fixture intact.

~~~sh
npm ci --ignore-scripts
npm --prefix astro ci --ignore-scripts
npm --prefix svelte ci --ignore-scripts
npm --prefix repo/spikes/backlog-chart ci --ignore-scripts
./repo/gradlew -p repo/site/generator generateSite
python3 assemble-content.py
(cd astro && ASTRO_TELEMETRY_DISABLED=1 npm exec -- astro build)
(cd svelte && npm exec -- vite build)
./repo/gradlew -p woge-content -PwogeRepository="$PILOT_REPOSITORY" installDist
./repo/gradlew -p repo/spikes/backlog-chart -PwogeRepository="$PILOT_REPOSITORY" installDist
npm exec -- playwright install chromium
npm exec -- playwright test
python3 summarize-evidence.py
~~~

The Gradle tasks and factory defaults resolve the versions pinned by Woge. The Woge settings
harness is a study-only application. The generic static hosts serve the two public article
exports. The dynamic behavior runs on the paired Ktor and Node processes. The comparisons
exercise small read-only and cookie-only fixtures and send no data to an external application.

The included aborted runs document setup errors and corrections. The accepted browser run is
`browser-final.log` with `browser-result.json`, `content-raw.json`, and `chart-raw.json`.
The local chart test checks a single fixed snapshot. The #340 comparison context documents
Woge's separate date selection and parent-update lifecycle.
