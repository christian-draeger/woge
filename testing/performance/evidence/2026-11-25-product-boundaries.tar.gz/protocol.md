# Product boundaries study protocol

Declared 2026-11-25 before the comparator implementations. Method under Woge #284.
No framework ranking, hosted capacity, human-study, offline or collaborative claim.

## Content case

Question: can a small Kotlin documentation publisher serve a useful, cacheable public article
and still offer a public, per-browser topic preference? Compare the existing Woge static
generator plus an application-owned handoff to the pinned Ktor fixture with the Astro static
article plus a Node server island and form. Use the exact `site/content/tasks.md` article and
checked-in snippet, one named heading set, title/description and the same underlying CSS.
The comparison covers that article, rather than Woge's complete five-page navigation model or
Astro's entire authoring ecosystem.

Acceptance: equivalent article prose, valid headings/metadata/CSS and readable snippet without
JavaScript. The exported article must open on a static server. With the associated live runtime,
one native destination supports reading and changing an allowlisted non-secret topic, reloading
retains the selection, a fresh browser context starts with the default, and ordinary navigation
still works with JavaScript disabled. With JavaScript enabled the article shows the current
preference without loading the article again. Record identical platform cache controls where
selected and distinguish app defaults, test serving policy and actual external deployment.
Stop the dynamic comparison if those outputs or isolation checks fail. Record actual build
commands, the article byte sizes, authored seams and observed browser requests.

## Local business widget case

Question: when all local state is inside a single warehouse backlog chart, what costs are
added by the Woge island and a SvelteKit prerendered screen? Pin Woge #340
`1741e20f9df2a4221fb274df8f6a8ad15d54dfbb` and the fixed 7bf1e3e beta kit. Use Chart.js 4.6.2,
the exact early 14-row warehouse snapshot, same canvas dimensions, series, Chart.js
registration and styling. Use the same narrow latency endpoint and count runtime bytes per
browser request. The comparison covers a read-only report and local controls. Woge's separate
date-selection POST, keyed enhanced parent updates and reset lifecycle remain reported under
#340 and outside the comparator's static deployment slice.

Acceptance: JavaScript-disabled browser reads the fourteen exact rows, no chart module requested
above the fold, scrolling into view loads the chart, keyboard-packed-series toggle and latest
four-day viewport each redraw and change the accessible pressed state with no network request.
Stop comparisons if textual values, initialization or agreed keyboard controls differ.
Use three rotated cold-context samples in Chromium per mode, same machine, no throttles,
loopback, no proxy. Record responses/bodies and button-event-to-next-frame observations.
Small sample measurements are descriptive. No startup or maintainability ranking follows from
component size or the declared timing.

## Unmeasured matrix entries

Use dated upstream documentation and distinguish released features, optional choices and
preview status. Reuse #288 widget and owner-search evidence. #277 owns the pending Next.js
full deployment comparison, whose absent results stay unknown. Select a Vaadin grid comparison
only if a real editable-grid workflow warrants it.
