from pathlib import Path
import re
import shutil

root = Path(__file__).resolve().parent
repo = root / "repo"
text = (repo / "site/content/tasks.md").read_text()
def snippet(match):
    return "\n".join(["```kotlin", (repo / match[1]).read_text().rstrip(), "```"])
text = re.sub(r"^<!-- snippet: (.+) -->$", snippet, text, flags=re.M)
(root / "astro/src/content/tasks.md").write_text(text)
shutil.copyfile(repo / "site/static/site.css", root / "astro/src/styles/site.css")
if (repo / "site/generator/build/site").is_dir():
    output = root / "woge-content/static"
    shutil.copytree(repo / "site/generator/build/site", output, dirs_exist_ok=True)
    page = output / "tasks.html"
    insertion = """<section aria-labelledby="study-topic-heading"><h2 id="study-topic-heading">Reading preferences</h2><p data-current-topic>Preferences are available on the settings page.</p><p><a href="/preferences">Change reading preferences</a></p></section><script type="module" src="/assets/topic-study.js"></script>"""
    text = page.read_text()
    assert text.count("</main>") == 1
    page.write_text(text.replace("</main>", insertion + "</main>"))
    (output / "assets/topic-study.js").write_text("""const topic = document.querySelector("[data-current-topic]");
try {
  const response = await fetch("/preferences/topic", { cache: "no-store" });
  if (response.ok) topic.textContent = "Topic: " + (await response.json()).topic;
} catch {
  // The settings link remains useful when the optional request fails.
}
""")
