package study

import dev.woge.html.applicationUrl
import dev.woge.html.renderHtml
import dev.woge.html.title
import io.ktor.http.ContentType
import io.ktor.http.HttpHeaders
import io.ktor.http.HttpStatusCode
import io.ktor.server.engine.embeddedServer
import io.ktor.server.http.content.staticFiles
import io.ktor.server.netty.Netty
import io.ktor.server.request.header
import io.ktor.server.request.receiveText
import io.ktor.server.response.respond
import io.ktor.server.response.respondFile
import io.ktor.server.response.respondText
import io.ktor.server.routing.get
import io.ktor.server.routing.post
import io.ktor.server.routing.routing
import java.io.File

private val topics = mapOf("operations" to "Operations", "delivery" to "Delivery")
private const val topicCookie = "study-topic"

private fun topic(cookie: String?): String = topics[cookie] ?: "Overview"

private fun preferences(current: String, invalid: Boolean = false): String =
    renderHtml {
        doctype()
        element("html", { attribute("lang", "en") }) {
            element("head") {
                voidElement("meta") { attribute("charset", "utf-8") }
                title("Reading preferences")
            }
            element("body") {
                element("main") {
                    element("h1") { text("Reading preferences") }
                    element("p", { data("current-topic", "") }) { text("Topic: $current") }
                    if (invalid) element("p", { attribute("role", "alert") }) { text("Choose a listed topic.") }
                    element("form", { attribute("method", "post"); url("action", applicationUrl("/preferences")) }) {
                        element("label", { attribute("for", "topic") }) { text("Reading topic") }
                        element("select", { attribute("id", "topic"); attribute("name", "topic") }) {
                            topics.forEach { (value, label) ->
                                element("option", { attribute("value", value) }) { text(label) }
                            }
                        }
                        element("button") { text("Save topic") }
                    }
                    element("p") {
                        element("a", { url("href", applicationUrl("/tasks.html")) }) { text("Return to the article") }
                    }
                }
            }
        }
    }

fun main() {
    val port = System.getenv("PORT").toInt()
    val static = File(System.getenv("WOGE_STUDY_STATIC"))
    embeddedServer(Netty, host = "127.0.0.1", port = port) {
        routing {
            get("/tasks.html") {
                call.response.headers.append(HttpHeaders.CacheControl, "public, max-age=60")
                call.respondFile(static.resolve("tasks.html"))
            }
            get("/preferences") {
                call.response.headers.append(HttpHeaders.CacheControl, "private, no-store")
                call.respondText(preferences(topic(call.request.cookies[topicCookie])), ContentType.Text.Html)
            }
            get("/preferences/topic") {
                call.response.headers.append(HttpHeaders.CacheControl, "private, no-store")
                val current = topic(call.request.cookies[topicCookie])
                call.respondText("""{"topic":"$current"}""", ContentType.Application.Json)
            }
            post("/preferences") {
                call.response.headers.append(HttpHeaders.CacheControl, "private, no-store")
                val length = call.request.header(HttpHeaders.ContentLength)?.toIntOrNull()
                if (call.request.header(HttpHeaders.Origin) != "http://127.0.0.1:$port") {
                    call.respond(HttpStatusCode.Forbidden)
                    return@post
                }
                val body = if (length != null && length in 1..128) call.receiveText() else ""
                val submitted = body.takeIf { it.startsWith("topic=") }?.removePrefix("topic=")
                if (submitted !in topics) {
                    call.respondText(preferences(topic(call.request.cookies[topicCookie]), invalid = true),
                        ContentType.Text.Html, HttpStatusCode.BadRequest)
                    return@post
                }
                call.response.headers.append(HttpHeaders.SetCookie, "$topicCookie=$submitted; Path=/; HttpOnly; SameSite=Lax")
                call.response.headers.append(HttpHeaders.Location, "/preferences")
                call.respond(HttpStatusCode.SeeOther)
            }
            staticFiles("/", static)
        }
    }.start(wait = true)
}
