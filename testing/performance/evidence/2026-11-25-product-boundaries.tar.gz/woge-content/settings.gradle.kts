rootProject.name = "woge-content-study"
