plugins {
    application
    kotlin("jvm") version "2.4.10"
}

repositories {
    exclusiveContent {
        forRepository { maven { url = uri(file(providers.gradleProperty("wogeRepository").get())) } }
        filter { includeGroup("dev.woge") }
    }
    mavenCentral()
}

dependencies {
    implementation("dev.woge:woge-core:0.1.0-beta.1")
    implementation("io.ktor:ktor-server-netty-jvm:3.5.2")
}

kotlin { jvmToolchain(21) }
application { mainClass = "study.PreferenceServerKt" }
