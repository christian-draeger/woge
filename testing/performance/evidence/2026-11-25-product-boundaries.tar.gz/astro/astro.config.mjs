import { defineConfig } from "astro/config";
import node from "@astrojs/node";
import { satteri } from "@astrojs/markdown-satteri";

export default defineConfig({
  build: { format: "file" },
  markdown: { processor: satteri({ features: { smartPunctuation: false } }) },
  adapter: node({ mode: "standalone", staticHeaders: true, bodySizeLimit: 8192 }),
});
