import { defineAction } from "astro:actions";
import { z } from "astro/zod";

export const server = {
  chooseTopic: defineAction({
    accept: "form",
    input: z.object({ topic: z.enum(["operations", "delivery"]) }),
    handler: ({ topic }, { cookies }) => {
      cookies.set("study-topic", topic, { path: "/", httpOnly: true, sameSite: "lax" });
      return { ok: true };
    },
  }),
};
