#!/usr/bin/env python3
from collections import defaultdict
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import zipfile

FOLDER = Path(__file__).resolve().parent
REPO = FOLDER / "repo"
LINUX_JAVA = Path(os.environ["WOGE_STUDY_LINUX_JAVA_HOME"])
spec = importlib.util.spec_from_file_location("reference_demo", REPO / "scripts/reference-demo.py")
reference = importlib.util.module_from_spec(spec)
spec.loader.exec_module(reference)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


host_packages = defaultdict(dict)
for host in reference.HOSTS:
    name, packaged, launch = reference.package(host, reference.version(), "java")
    if packaged.is_file():
        with zipfile.ZipFile(packaged) as archive:
            files = sorted(entry for entry in archive.namelist() if entry.startswith("BOOT-INF/lib/") and entry.endswith(".jar"))
    else:
        files = sorted(str(entry.relative_to(packaged)) for entry in (packaged / "lib").glob("*.jar"))
    host_packages[host] = {
        "buildTask": name, "launch": [str(part).replace(str(REPO) + "/", "") for part in launch],
        "artifact": str(packaged.relative_to(REPO)), "artifactSha256": reference.artifact_hashes(packaged),
        "runtimeJars": files,
    }

manifest = {
    "studyProtocol": "protocol.json",
    "studyProtocolSha256": sha(FOLDER / "protocol.json"),
    "sourceCommit": reference.output("git", "rev-parse", "HEAD"),
    "dirty": bool(reference.output("git", "status", "--porcelain")),
    "version": reference.version(),
    "workloadInputs": {str(path.relative_to(REPO)): sha(path) for path in [
        REPO / "docs/performance/comparison-contract.md",
        REPO / "examples/reference-application/shared/src/main/kotlin/dev/woge/example/project/ProjectData.kt",
        REPO / "examples/reference-application/shared/src/main/kotlin/dev/woge/example/project/ProjectPage.kt",
        REPO / "scripts/reference-demo.py",
        REPO / "client/woge-fallback-client/package-lock.json",
        REPO / "client/woge-fallback-client/reference-browser-tests/performance.enhanced.spec.mjs",
        REPO / "testing/performance/browser-policy.json",
        REPO / "gradle/libs.versions.toml",
    ]},
    "build": {
        "commands": ["(cd client/woge-fallback-client && npm ci --no-audit --no-fund)",
                     "(cd client/woge-fallback-client && node scripts/build-reference-theme.mjs)",
                     "./gradlew --no-daemon --no-build-cache --console=plain :woge-reference-spring-webflux:bootJar :woge-reference-spring-mvc:bootJar :woge-reference-ktor:installDist"],
        "operatingSystem": reference.output("uname", "-srv"),
        "java": reference.output(os.environ["JAVA_HOME"] + "/bin/java", "-version"),
        "node": reference.output("node", "--version"),
        "gradle": "8.14.4 (wrapper)",
        "dependencyCache": "Warm Gradle dependency cache, new checkout and local npm cache, task output build cache disabled",
    },
    "hosts": host_packages,
    "studyDrivers": {filename: sha(FOLDER / filename) for filename in
                     ["http_study.py", "linux-browser-study.sh", "linux-maintained-budgets.sh", "run-linux.sh"]},
    "browserTimingAmendment": {"path": "browser-amendment.json", "sha256": sha(FOLDER / "browser-amendment.json")},
    "runtime": {
        "playwrightPackage": "1.62.1",
        "container": "mcr.microsoft.com/playwright:v1.62.1-noble@sha256:dcc5531e97840b9b5e794f2814476b21571c5124a3fca2267d73041f56e7580e",
        "jdkReleaseFileSha256": sha(LINUX_JAVA / "release"),
        "jdkBinarySha256": sha(LINUX_JAVA / "bin/java"),
        "limitsAndToolVersions": "browser/environment.txt",
        "serverState": "Fresh packaged JVM for each rotated host/round, normal reference profile, no proxy",
    },
}
(FOLDER / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(manifest["sourceCommit"], manifest["dirty"], list(manifest["hosts"]))
