#!/usr/bin/env python3
"""Run packaged JVMs in rotated blocks and bound every fresh Chromium process."""
from http_study import HERE, REPO, SPEC, dump, run_arrivals, server
import json
import os
import signal
import subprocess

directory = HERE / "navigation"
directory.mkdir()
summaries = []
for number, order in enumerate(SPEC["rotation"], 1):
    for host in order:
        output = directory / f"round-{number}-{host}"
        output.mkdir()
        conditions = ["loopback", "constrained"]
        if number % 2 == 0:
            conditions.reverse()
        report = {"host": host, "round": number, "samples": []}
        with server(host, output) as (port, pid):
            warmup = SPEC["http"]["warmup"]
            dump(output / "warmup.json", run_arrivals(port, pid, warmup["ratePerSecond"], warmup["seconds"]))
            with (output / "browser.log").open("w") as log:
                for condition in conditions:
                    for index in range(1, SPEC["browser"]["samplesPerConditionPerRound"] + 1):
                        scratch = output / f"{condition}-{index}.json"
                        command = ["node", str(HERE / "browser-timing.mjs"), host, str(port), str(number),
                                   str(scratch), condition, str(index)]
                        process = subprocess.Popen(command, cwd=REPO, stdout=log, stderr=subprocess.STDOUT,
                                                   start_new_session=True)
                        try:
                            exit_code = process.wait(timeout=30)
                        except subprocess.TimeoutExpired:
                            os.killpg(process.pid, signal.SIGKILL)
                            process.wait(timeout=5)
                            exit_code = 124
                        if scratch.exists():
                            sample = json.loads(scratch.read_text())
                            report["chromium"] = sample["chromium"]
                            report["samples"].extend(sample["samples"])
                        else:
                            report["samples"].append({"condition": condition, "sample": index, "outcome": "error",
                                                      "problem": f"Browser process exited {exit_code} without a sample"})
                        dump(output / "browser-timing.json", report)
            issues = sum(sample["outcome"] == "error" for sample in report["samples"])
            summaries.append({"round": number, "host": host, "errors": issues, "samples": len(report["samples"])})
            dump(directory / "summary.json", summaries)
            print(summaries[-1], flush=True)
