#!/usr/bin/env bash
set -euo pipefail
cd /study/repo/client/woge-fallback-client
export PATH="$JAVA_HOME/bin:$PATH"

mkdir -p /study/browser
{
  uname -a
  cat /etc/os-release
  java -version
  node --version
  npm --version
  cat /sys/fs/cgroup/cpu.max /sys/fs/cgroup/memory.max
  cat node_modules/playwright-core/browsers.json
} > /study/browser/environment.txt 2>&1
for host in spring-webflux spring-mvc ktor; do
  export WOGE_REFERENCE_HOST="$host" WOGE_REFERENCE_PORT=18400 WOGE_REFERENCE_PACKAGED=1
  export WOGE_REFERENCE_REPORT_DIR="/study/browser/$host-conformance"
  mkdir -p "$WOGE_REFERENCE_REPORT_DIR"
  set +e
  npm run test:reference -- --global-timeout 180000 --grep-invert "real adapter production budgets" > "$WOGE_REFERENCE_REPORT_DIR/runner.log" 2>&1
  exit_code=$?
  printf '%d\n' "$exit_code" > "$WOGE_REFERENCE_REPORT_DIR/exit-code.txt"
  set -e
done
