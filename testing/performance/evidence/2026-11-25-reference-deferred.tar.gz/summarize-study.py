#!/usr/bin/env python3
"""Summarize independent rounds without pooling unlike hosts or timings."""
import json
from pathlib import Path
from statistics import median
from collections import Counter

from http_study import SPEC

HERE = Path(__file__).resolve().parent


def read(path):
    return json.loads(path.read_text())


def descriptor(values):
    return {"median": round(median(values), 3), "range": [round(min(values), 3), round(max(values), 3)]}


result = {"http": {}, "browserConformance": {}, "browserTiming": {}}
rounds = read(HERE / "measured" / "summary.json")
for host in SPEC["hosts"]:
    grouped = {}
    for rate in SPEC["http"]["arrivalRatesPerSecond"]:
        selected = [trial for trial in rounds if trial["host"] == host and trial["rate"] == rate]
        metrics = ("scheduledToCompleteMs", "dispatchToCompleteMs", "generatorQueueMs", "shellMs", "firstPatchMs")
        grouped[str(rate)] = {
            "rounds": [trial["round"] for trial in selected],
            "offered": sum(trial["scheduled"] for trial in selected),
            "correct": sum(trial["outcomes"]["correct"] for trial in selected),
            "errors": {label: sum(trial["outcomes"][label] for trial in selected)
                       for label in ("timeout", "dropped", "error")},
            "within750Ms": sum(trial["within750Ms"] for trial in selected),
            "startedPerSecondInWindow": descriptor([trial["startedPerSecondInWindow"] for trial in selected]),
            "completedPerSecondIncludingDrain": descriptor([trial["correctCompletionPerSecondThroughDrain"] for trial in selected]),
            "metrics": {metric: {quantile: descriptor([trial[metric][quantile] for trial in selected if metric in trial])
                                 for quantile in ("p50", "p95")} for metric in metrics
                        if any(metric in trial for trial in selected)},
            "bodyBytes": [trial.get("bodyBytes") for trial in selected],
            "cpuSeconds": descriptor([trial["cpuSeconds"] for trial in selected]),
        }
    controls = []
    for path in sorted((HERE / "measured").glob(f"round-*-{host}/controls.json")):
        controls.append({"round": path.parent.name, **read(path)})
    grouped["controls"] = {
        "count": len(controls),
        "nativeBytes": sorted({trial["native"].get("htmlBodyBytes") for trial in controls}),
        "disconnectOutcomes": dict(Counter(trial["disconnect"]["outcome"] for trial in controls)),
        "postDisconnectOutcomes": dict(Counter(trial["afterDisconnect"]["outcome"] for trial in controls)),
        "postDrainEstablished": [trial["afterDrain"]["establishedInbound"] for trial in controls],
        "postDrainRSSKiB": [trial["afterDrain"]["rssKiB"] for trial in controls],
        "postDrainOpenFds": [trial["afterDrain"]["openFds"] for trial in controls],
        "shutdown": [read(path) for path in sorted((HERE / "measured").glob(f"round-*-{host}/shutdown.json"))],
    }
    result["http"][host] = grouped

    conformance = HERE / "browser" / f"{host}-conformance"
    junit = read(conformance / "browser.json")
    result["browserConformance"][host] = {"exit": int((conformance / "exit-code.txt").read_text()),
                                           "stats": junit["stats"]}

    timing_blocks = []
    for path in sorted((HERE / "maintained-navigation").glob(f"round-*-{host}")):
        if not (path / "exit-code.txt").exists():
            continue
        exit_code = int((path / "exit-code.txt").read_text())
        report_path = path / "browser-budget.json"
        raw = read(report_path) if report_path.exists() else {}
        timing_blocks.append({"round": path.name.split("-")[1], "exitCode": exit_code,
                              "samples": raw.get("samples", []), "median": raw.get("median", {})})
    accepted = [block for block in timing_blocks if block["exitCode"] == 0 and len(block["samples"]) == 3]
    result["browserTiming"][host] = {
        "blocks": len(timing_blocks),
        "acceptedBlocks": len(accepted),
        "acceptedSamples": sum(len(block["samples"]) for block in accepted),
        "blocksFailed": [block["round"] for block in timing_blocks if block not in accepted],
        "medians": {
            metric: {**descriptor([block["median"][metric] for block in accepted]),
                     "roundMedians": {block["round"]: block["median"][metric] for block in accepted}}
            for metric in ("firstShell", "firstPatch", "patchApply") if accepted
        },
    }

(HERE / "result-summary.json").write_text(json.dumps(result, indent=2) + "\n")
