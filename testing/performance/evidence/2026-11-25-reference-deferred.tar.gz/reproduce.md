# Reproduce the reference deferred study

Use a new scratch directory, place these study files at its root, and check out the manifest's source
revision under `repo`. Build the three packages with the manifest commands. Run each phase
sequentially so the servers, browser and load generators do not contend with another study phase.
The retained HTML artifact reports are available from the local experiment directory. The evidence
bundle preserves the browser runner logs and JSON reports.

Set `WOGE_STUDY_LINUX_JAVA_HOME` to an unpacked Linux arm64 Temurin 21.0.12.1+1 JDK. The
manifest records the release metadata and binary checksums. In a clean reproduction, the
phase output folders do not yet exist. Move previous folders aside to retain comparisons.

~~~sh
bash run-linux.sh bash /study/linux-browser-study.sh
bash run-linux.sh python3 /study/http_study.py pilot
bash run-linux.sh python3 /study/http_study.py measured
bash run-linux.sh bash /study/linux-maintained-budgets.sh
python3 make-manifest.py
python3 summarize-study.py
~~~

The Linux driver uses `scripts/reference-demo.py serve` to run the packaged artifacts.
The three-engine conformance command is the maintained reference-demo runner's Playwright
configuration with its separate budget test excluded. The browser timing uses the exact maintained Chromium budget probe. The browser amendment records
the calibration limits and the revised browser measurement boundaries.
