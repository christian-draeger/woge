#!/usr/bin/env bash
set -euo pipefail
cd /study/repo/client/woge-fallback-client
mkdir /study/maintained-navigation
while read -r round host; do
  export WOGE_REFERENCE_HOST="$host" WOGE_REFERENCE_PORT=18400 WOGE_REFERENCE_PACKAGED=1
  export WOGE_REFERENCE_REPORT_DIR="/study/maintained-navigation/round-$round-$host"
  mkdir -p "$WOGE_REFERENCE_REPORT_DIR"
  set +e
  npm run test:reference -- --global-timeout 60000 --grep "real adapter production budgets" --project chromium-enhanced \
    > "$WOGE_REFERENCE_REPORT_DIR/runner.log" 2>&1
  exit_code=$?
  printf '%d\n' "$exit_code" > "$WOGE_REFERENCE_REPORT_DIR/exit-code.txt"
  printf '%s %s %s\n' "$round" "$host" "$exit_code"
  set -e
done <<'ROUNDS'
1 spring-webflux
1 spring-mvc
1 ktor
2 spring-mvc
2 ktor
2 spring-webflux
3 ktor
3 spring-webflux
3 spring-mvc
ROUNDS
