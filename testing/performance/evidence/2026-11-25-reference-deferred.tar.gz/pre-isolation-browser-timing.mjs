import { chromium } from "./repo/client/woge-fallback-client/node_modules/playwright/index.mjs";
import { writeFile } from "node:fs/promises";

const [host, port, round, output] = process.argv.slice(2);
const origin = `http://127.0.0.1:${port}`;
const conditions = [
  { name: "loopback", throttle: 1 },
  {
    name: "constrained",
    throttle: 4,
    latency: 80,
    downloadThroughput: 187500,
    uploadThroughput: 93750,
  },
];
if (Number(round) % 2 === 0) conditions.reverse();

const browser = await chromium.launch();
const report = { host, round: Number(round), chromium: browser.version(), conditions, samples: [] };

try {
  for (const condition of conditions) {
    for (let sample = 1; sample <= 4; sample++) {
      const context = await browser.newContext({ viewport: { width: 1280, height: 900 } });
      const page = await context.newPage();
      const result = { condition: condition.name, sample, outcome: "error" };
      const errors = [];
      page.on("pageerror", error => errors.push(error.message));
      page.on("console", message => {
        if (message.type() === "error") errors.push(message.text());
      });
      try {
        const session = await context.newCDPSession(page);
        await session.send("Network.enable");
        await session.send("Network.setCacheDisabled", { cacheDisabled: true });
        if (condition.throttle > 1) {
          const { latency, downloadThroughput, uploadThroughput } = condition;
          await session.send("Emulation.setCPUThrottlingRate", { rate: condition.throttle });
          await session.send("Network.emulateNetworkConditions", {
            offline: false, latency, downloadThroughput, uploadThroughput,
          });
        }
        await session.send("Performance.enable");
        const before = await session.send("Performance.getMetrics");
        await page.addInitScript(() => {
          globalThis.wogeStudy = { shellMs: null, completeMs: null, patches: [] };
          function visible(element) {
            return element && element.getClientRects().length > 0 && getComputedStyle(element).visibility === "visible";
          }
          const activities = ["Standards-native CSS contract implemented", "Server adapter contract verified"];
          const tasks = ["Publish the first web-first guide", "Verify the deferred browser path", "Record the architecture decision"];
          const starts = new WeakMap();
          document.addEventListener("woge:before-replace", event => starts.set(event.target, performance.now()));
          document.addEventListener("woge:after-replace", event => {
            if (starts.has(event.target)) globalThis.wogeStudy.patches.push(performance.now() - starts.get(event.target));
          });
          function frame() {
            const measurement = globalThis.wogeStudy;
            const heading = document.querySelector("main h1");
            const fallback = document.querySelector('button[name="view"][value="complete"]');
            const regions = [...document.querySelectorAll('main [data-woge-region]')];
            if (measurement.shellMs === null && visible(heading) && heading.textContent === "Woge"
                && visible(fallback) && regions.length === 3
                && [...document.styleSheets].some(style => style.href?.endsWith("/assets/application.css"))) {
              measurement.shellMs = performance.now();
            }
            const table = document.querySelector(".project-region table");
            const activity = document.querySelector(".project-region .activity-list");
            if (measurement.shellMs !== null && regions.length === 3
                && regions.every(region => region.dataset.wogeRevision === "1" && visible(region))
                && visible(table) && tasks.every(text => table.textContent.includes(text))
                && visible(activity) && activities.every(text => activity.textContent.includes(text))
                && !document.querySelector(".is-loading")) {
              measurement.completeMs = performance.now();
            } else {
              requestAnimationFrame(frame);
            }
          }
          requestAnimationFrame(frame);
        });
        const awaitedPatch = page.waitForResponse(response => response.url().includes("/projects/woge/woge-patches/"),
                                                 { timeout: 10000 });
        awaitedPatch.catch(() => {}); // Always observe cancellation if navigation fails before awaiting it.
        const response = await page.goto(origin + "/projects/woge", { waitUntil: "commit", timeout: 10000 });
        const patch = await awaitedPatch;
        if (response.status() !== 200 || patch.status() !== 200) throw new Error("unexpected response status");
        await page.waitForFunction(() => globalThis.wogeStudy?.completeMs !== null && !!globalThis.wogeStudy?.shellMs,
                                   null, { timeout: 10000 });
        const patchFailure = await patch.finished();
        if (patchFailure) throw patchFailure;
        await page.waitForFunction(
          () => performance.getEntriesByType("resource").some(entry => entry.name.includes("/projects/woge/woge-patches/")),
          null, { timeout: 10000 },
        );
        if (errors.length) throw new Error(errors.join(", "));
        const timings = await page.evaluate(() => {
          const all = [...performance.getEntriesByType("navigation"), ...performance.getEntriesByType("resource")];
          const resources = all.map(entry => ({
            urlPath: new URL(entry.name).pathname,
            transferBytes: entry.transferSize,
            encodedBodyBytes: entry.encodedBodySize,
            decodedBodyBytes: entry.decodedBodySize,
          }));
          return {
            ...globalThis.wogeStudy,
            documentInteractiveMs: all[0].domInteractive,
            firstContentfulPaintMs: performance.getEntriesByName("first-contentful-paint")[0]?.startTime,
            resources,
          };
        });
        if (timings.patches.length !== 3 || timings.shellMs >= timings.completeMs) {
          throw new Error("timing samples did not observe distinct shell and completed regions");
        }
        if (!timings.resources.some(resource => resource.urlPath.startsWith("/projects/woge/woge-patches/")
            && resource.decodedBodyBytes > 0)) throw new Error("patch resource timing was absent");
        const after = await session.send("Performance.getMetrics");
        const metrics = new Map(before.metrics.map(metric => [metric.name, metric.value]));
        result.rendererMs = Object.fromEntries(after.metrics
          .filter(metric => ["TaskDuration", "ScriptDuration", "LayoutDuration", "RecalcStyleDuration"].includes(metric.name))
          .map(metric => [metric.name, (metric.value - (metrics.get(metric.name) ?? 0)) * 1000]));
        result.htmlContentEncoding = (await response.headerValue("content-encoding")) ?? "identity";
        result.patchContentEncoding = (await patch.headerValue("content-encoding")) ?? "identity";
        Object.assign(result, timings, { outcome: "correct" });
      } catch (error) {
        result.problem = error.message;
      } finally {
        await context.close();
        report.samples.push(result);
        await writeFile(output, JSON.stringify(report, null, 2) + "\n");
      }
    }
  }
} finally {
  await browser.close();
}
if (report.samples.some(sample => sample.outcome === "error")) process.exitCode = 1;
