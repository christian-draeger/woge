#!/usr/bin/env python3
"""Run a fresh packaged JVM and browser process for each rotated navigation block."""
from http_study import HERE, REPO, SPEC, dump, run_arrivals, server
import subprocess

directory = HERE / "navigation"
directory.mkdir()
summaries = []
for number, order in enumerate(SPEC["rotation"], 1):
    for host in order:
        output = directory / f"round-{number}-{host}"
        output.mkdir()
        with server(host, output) as (port, pid):
            warmup = SPEC["http"]["warmup"]
            dump(output / "warmup.json", run_arrivals(port, pid, warmup["ratePerSecond"], warmup["seconds"]))
            with (output / "browser.log").open("w") as log:
                result = subprocess.run(
                    ["node", str(HERE / "browser-timing.mjs"), host, str(port), str(number),
                     str(output / "browser-timing.json")],
                    cwd=REPO, stdout=log, stderr=subprocess.STDOUT, timeout=150,
                )
            summaries.append({"round": number, "host": host, "exitCode": result.returncode})
            dump(directory / "summary.json", summaries)
            print(summaries[-1], flush=True)
