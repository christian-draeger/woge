# Woge deferred and live transport controls

The [#293](https://github.com/christian-draeger/woge/issues/293) controls use the fixed Woge reference packages from source `7fb2f6616e4115b4fb0050f872bef669cf8c5b88` and the same `/projects/woge` shell, native fallback and three delayed regions as the frozen traffic study. The two Spring Boot JARs and 54 Ktor distribution files matched the archived hashes. The mounted checkout adds three documentation and evidence files relative to the package source.

The normal client, two NGINX 1.28.3 policy endpoints, a deterministic full-body relay and a paced reader ran serially on independent Linux arm64 applications in three host rotations. NGINX ran in a separate sidecar sharing the isolated loopback namespace. Its modes selected `proxy_buffering off` and `proxy_buffering on` and ignored the upstream buffering directive, with no disk buffering or compression. Direct responses still exposed `X-Accel-Buffering: no` and the NGINX endpoints passed it to the observer. The positive-control relay sent headers immediately and released the complete deferred body on upstream EOF. The paced application reader requested at most 128 bytes after each 25 ms delay. [NGINX proxy directives](https://nginx.org/en/docs/http/ngx_http_proxy_module.html#proxy_buffering)

All 45 deferred journeys verified the preamble, three target-specific replacement frames, render hashes, revision metadata, completion frame and EOF. Each body was 1,820 bytes. All nine native and fresh recovery pairs passed, and shutdown observed zero open listeners and established inbound connections. Times are from issuing the deferred GET to parsing the frame.

| Transport | First complete frame median (min–max), ms | Terminal median (min–max), ms |
| --- | ---: | ---: |
| Direct | 130.1 (124.6–198.1) | 369.8 (366.3–390.5) |
| NGINX with buffering off | 130.4 (124.5–194.2) | 372.1 (365.1–397.4) |
| NGINX with buffering on | 131.3 (125.9–161.9) | 370.5 (366.3–376.3) |
| Full-body capture until EOF | 369.5 (365.7–398.6) | 369.5 (365.7–398.6) |
| Paced direct consumer | 234.8 (227.4–284.2) | 638.3 (623.6–689.4) |

Both NGINX policies delivered the first region before completion for these small responses. The explicit EOF hold removed that early delivery. The paced application consumer parsed every frame. The tiny body and unthrottled socket buffers are insufficient to demonstrate sustained transport backpressure, a memory bound under slow downstream consumers or behavior of other proxy configurations. The timings are descriptive.

The separate raw SSE control committed one warm-up task, twelve connected tasks while the observer paused reading, and six tasks with its connection closed. All three hosts returned 303 for each mutation and delivered twelve invalidations for the twelve connected writes. The bursts lasted 63.2–86.2 ms. Every reconnect used the last observed event ID and returned the next-ID resync for the original target. The current activity GET showed exactly nineteen changes, fresh native reads confirmed the advanced version, and all sockets drained. This exercised burst and reconnect recovery. It did not exhibit notification coalescing or retest the browser's draft behavior.

## Reproduce

Unpack the raw files in a new directory. Set `WOGE_STUDY_REPO` to the archived source with the existing packaged reference applications and `WOGE_STUDY_LINUX_JAVA_HOME` to the unpacked Linux arm64 Temurin 21.0.12.1+1 distribution. The launchers use the pinned local NGINX and Playwright container images, network isolation and the original heap and CPU limits.

```sh
python3 verify-artifacts.py
./launch.sh
./launch-live.sh
```

Run in a fresh directory to retain existing result sets. The proxy and live drivers, plans, effective NGINX configuration and versions, archival package manifest, artifact verification, raw observations, and server startup and shutdown logs accompany this report.
