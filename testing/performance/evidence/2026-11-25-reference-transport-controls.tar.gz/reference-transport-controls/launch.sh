#!/usr/bin/env bash
set -euo pipefail
study=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
: "${WOGE_STUDY_REPO:?Set this to source 7fb2f66 with its packaged reference applications}"
: "${WOGE_STUDY_LINUX_JAVA_HOME:?Set this to unpacked Linux arm64 Temurin 21.0.12.1+1}"
study_job="woge293-control-$$"
relay_job="$study_job-nginx"
study_image="mcr.microsoft.com/playwright:v1.62.1-noble@sha256:dcc5531e97840b9b5e794f2814476b21571c5124a3fca2267d73041f56e7580e"
nginx_image="nginx@sha256:a8b39bd9cf0f83869a2162827a0caf6137ddf759d50a171451b335cecc87d236"
cleanup() {
    docker logs "$relay_job" > "$study/nginx.log" 2>&1 || true
    docker rm -f "$relay_job" "$study_job" >/dev/null 2>&1 || true
    rm -f "$study/start"
}
trap cleanup EXIT
docker image inspect "$study_image" "$nginx_image" --format '{{.Id}} {{.Architecture}}' > "$study/images.txt"
docker run -d --pull=never --name "$study_job" --network none --platform linux/arm64 --cpus 2 --memory 2g \
    --mount "type=bind,source=$study,target=/study" \
    --mount "type=bind,source=$WOGE_STUDY_REPO,target=/study/repo,readonly" \
    --mount "type=bind,source=$WOGE_STUDY_LINUX_JAVA_HOME,target=/jvm,readonly" \
    --env JAVA_HOME=/jvm \
    --env 'JAVA_TOOL_OPTIONS=-Xms128m -Xmx512m -XX:+UseG1GC -XX:ActiveProcessorCount=2' \
    "$study_image" bash -ec 'export PATH="$JAVA_HOME/bin:$PATH"; cd /study; while [ ! -f /study/start ]; do sleep 0.1; done; exec python3 controls.py' >/dev/null
docker run -d --pull=never --name "$relay_job" --platform linux/arm64 --cpus 0.5 --memory 128m \
    --network "container:$study_job" \
    --mount "type=bind,source=$study/nginx.conf,target=/etc/nginx/nginx.conf,readonly" \
    "$nginx_image" nginx -g 'daemon off;' >/dev/null
docker exec "$relay_job" nginx -V > "$study/nginx-version.txt" 2>&1
docker exec "$relay_job" nginx -T > "$study/nginx-effective-config.txt" 2>&1
touch "$study/start"
docker logs -f "$study_job"
status=$(docker wait "$study_job")
test "$status" = 0
