"""Verify the mounted JVM packages and workload inputs against the frozen manifest."""

import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path(os.environ["WOGE_STUDY_REPO"])
here = Path(__file__).resolve().parent
manifest = json.loads((here / "manifest.json").read_text())
head = subprocess.check_output(["git", "-C", str(root), "rev-parse", "HEAD"], text=True).strip()
changed = subprocess.check_output(
    ["git", "-C", str(root), "diff", "--name-only", manifest["sourceCommit"], head], text=True,
).splitlines()
result = {"recordedPackageSourceCommit": manifest["sourceCommit"], "mountedCheckoutHead": head,
          "checkoutFilesDifferentFromPackageSource": changed, "verified": {}}
for path, expected in manifest["workloadInputs"].items():
    assert hashlib.sha256((root / path).read_bytes()).hexdigest() == expected, path
for host, package in manifest["hosts"].items():
    result["verified"][host] = {}
    for path, expected in package["artifactSha256"].items():
        actual = hashlib.sha256((root / path).read_bytes()).hexdigest()
        assert actual == expected, (host, path)
        result["verified"][host][path] = actual
(here / "artifact-verification.json").write_text(json.dumps(result, indent=2) + "\n")
