"""Small synthetic live burst, disconnect, resync and current-read control."""

from contextlib import closing, contextmanager
from html.parser import HTMLParser
import http.client
import json
from pathlib import Path
import time
from urllib.parse import urlencode

from controls import drain, get
from http_study import DEFERRED_TYPE, HERE, SHELL, dump, elapsed_ms, expect, parse_frame, server

BOARD = f"{SHELL}/tasks"
HOSTS = ("spring-webflux", "spring-mvc", "ktor")


class Board(HTMLParser):
    def __init__(self, rendered):
        super().__init__()
        self.fields = {}
        self.metadata = {}
        self.activity = None
        self.action = None
        self.feed(rendered)

    def handle_starttag(self, tag, attributes):
        values = dict(attributes)
        if tag == "meta" and values.get("name", "").startswith("woge-"):
            self.metadata[values["name"]] = values.get("content")
        if tag == "input" and values.get("form") == "board-form":
            self.fields[values["name"]] = values.get("value", "")
        if values.get("id") == "board-activity":
            self.activity = values.get("data-woge-region")
        if values.get("id") == "board-form":
            self.action = values.get("action")


def board(port):
    with closing(http.client.HTTPConnection("127.0.0.1", port, timeout=4)) as conn:
        with get(conn, BOARD, "text/html", port) as response:
            snapshot = Board(response.read(256 * 1024).decode())
    expect(snapshot.action == "/woge-actions/add-board-task" and snapshot.activity and
           set(snapshot.fields) >= {"epoch", "version", "revision", "edit"} and
           snapshot.metadata.get("woge-live-url") == f"{BOARD}/live/{snapshot.fields['epoch']}",
           "missing form or live board metadata")
    return snapshot


def active_fields(port, snapshot, version, names):
    operations = []
    with closing(http.client.HTTPConnection("127.0.0.1", port, timeout=4)) as conn:
        for offset, title in enumerate(names):
            fields = {**snapshot.fields, "version": version + offset, "title": title, "owner": "Study Team"}
            started = time.monotonic_ns()
            conn.request("POST", snapshot.action, body=urlencode(fields), headers={
                "Content-Type": "application/x-www-form-urlencoded", "Origin": f"http://127.0.0.1:{port}",
                "Accept": "text/html",
            })
            with conn.getresponse() as response:
                operations.append({"title": title, "status": response.status, "startedNs": started,
                                   "completedNs": time.monotonic_ns(), "location": response.getheader("Location")})
                expect(response.status == 303 and response.getheader("Location") == BOARD,
                       f"expected a native commit and 303 redirect, received {response.status}")
                response.read()
    return operations


def sse(response):
    fields = {}
    data = []
    for _ in range(16):
        line = response.readline(1024)
        expect(bool(line), "SSE closed unexpectedly")
        if line in (b"\n", b"\r\n"):
            return {**fields, "data": data, "receivedNs": time.monotonic_ns()}
        key, _, value = line.decode().strip().partition(":")
        if key == "data":
            data.append(value.strip())
        elif key:
            fields[key] = value.strip()
    raise ValueError("unexpectedly large SSE event")


@contextmanager
def stream(port, snapshot, last=None):
    with closing(http.client.HTTPConnection("127.0.0.1", port, timeout=3)) as conn:
        headers = {"Accept": "text/event-stream", "Accept-Encoding": "identity"}
        if last is not None:
            headers["Last-Event-ID"] = str(last)
        conn.request("GET", snapshot.metadata["woge-live-url"], headers=headers)
        with conn.getresponse() as response:
            expect(response.status == 200 and
                   response.getheader("Content-Type", "").startswith("text/event-stream") and
                   response.getheader("X-Accel-Buffering") == "no", "unexpected SSE response")
            retry = sse(response)
            expect(retry.get("retry", "").isdigit(), "SSE did not provide a reconnect delay")
            yield conn, response, retry


def activity(port, snapshot, since, expected):
    result = {}
    path = f"{BOARD}/activity/{snapshot.fields['epoch']}/{snapshot.activity}/0/1?{urlencode({'since': since})}"
    with closing(http.client.HTTPConnection("127.0.0.1", port, timeout=4)) as conn:
        with get(conn, path, DEFERRED_TYPE, port) as response:
            expect(response.read(5) == b"WOGE\x01", "wrong activity response preamble")
            kind, _, frame, rendered, payload = parse_frame(response)
            expect(kind == 1 and frame.get("target") == snapshot.activity and
                   f"{expected} tasks changed." in rendered, "activity did not show the current committed change count")
            result["notice"] = f"{expected} tasks changed."
            result["bytes"] = payload
            kind, _, terminal, _, _ = parse_frame(response)
            expect(kind == 2 and terminal == {"patches": 1} and not response.read(1), "invalid activity terminal")
    return result


def live_control(port):
    snapshot = board(port)
    version = int(snapshot.fields["version"])
    with stream(port, snapshot) as (conn, response, retry):
        warmup = active_fields(port, snapshot, version, ["Transport control warmup"])
        event = sse(response)
        expect(event.get("event") == "invalidate" and event["data"] == [snapshot.activity],
               "initial invalidation did not identify the activity region")
        connected = active_fields(port, snapshot, version + 1, [f"Transport connected {i}" for i in range(1, 13)])
        if conn.sock is not None:
            conn.sock.settimeout(0.45)
        burst = []
        try:
            while len(burst) <= 12:
                burst.append(sse(response))
        except TimeoutError:
            pass
    expect(0 < len(burst) <= 12, f"unexpected invalidation count {len(burst)}")
    expect(all(e.get("event") == "invalidate" and e["data"] == [snapshot.activity] for e in burst),
           "burst notified a target outside the declared activity region")
    ids = [int(event["id"]), *(int(e["id"]) for e in burst)]
    expect(ids == list(range(ids[0], ids[-1] + 1)), "live event identifiers did not increase")
    expect(drain(port) == 0, "the first SSE socket did not drain")
    offline = active_fields(port, snapshot, version + 13, [f"Transport offline {i}" for i in range(1, 7)])
    with stream(port, snapshot, last=ids[-1]) as (_, response, reconnect_retry):
        resync = sse(response)
        expect(resync.get("event") == "resync" and resync["data"] == [snapshot.activity] and
               int(resync["id"]) == ids[-1] + 1, "reconnect did not request a safe resync")
        notice = activity(port, snapshot, version, 19)
    latest = int(board(port).fields["version"])
    expect(latest - version == 19 and drain(port) == 0, "mutation count or connection cleanup was wrong")
    return {
        "warmup": warmup, "initialRetry": retry, "initialEvent": event, "connectedPosts": connected,
        "connectedBurstMs": elapsed_ms(connected[0]["startedNs"], connected[-1]["completedNs"]),
        "connectedEvents": burst, "offlinePosts": offline, "reconnectRetry": reconnect_retry,
        "resync": resync, "activity": notice, "initialBoardVersion": version, "finalBoardVersion": latest,
        "remainingEstablished": 0,
    }


def main():
    output = HERE / "live-results"
    output.mkdir()
    results = {"plan": json.loads((HERE / "live-plan.json").read_text()), "hosts": []}
    for host in HOSTS:
        record = {"host": host, "outcome": "error"}
        directory = output / host
        directory.mkdir()
        try:
            with server(host, directory) as (port, _):
                record.update(live_control(port), outcome="correct")
        except (ValueError, OSError, http.client.HTTPException) as error:
            record["problem"] = f"{type(error).__name__}: {error}"
        results["hosts"].append(record)
        dump(output / "results.json", results)
        print(host, record["outcome"], len(record.get("connectedEvents", ())), record.get("problem"), flush=True)
    expect(all(host["outcome"] == "correct" for host in results["hosts"]), "live control failed")


if __name__ == "__main__":
    main()
