#!/usr/bin/env python3
"""Inspect exact Woge D1 frames across two NGINX policies and bounded controls."""

from contextlib import closing, contextmanager
import hashlib
import http.client
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import platform
import subprocess
import threading
import time

from http_study import (
    BODY_LIMIT, DEFERRED_TYPE, EXPECTED, HERE, NATIVE, SHELL, SPEC, ShellMetadata,
    dump, elapsed_ms, expect, parse_frame, project_journey, server, tcp_count,
)

MODES = ("direct", "nginx-off", "nginx-on", "capture-entire", "paced-direct")
PROXY_PORTS = {"nginx-off": 18081, "nginx-on": 18082}


@contextmanager
def captured_response(upstream_port):
    class CaptureHandler(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"

        def do_GET(self):
            with closing(http.client.HTTPConnection("127.0.0.1", upstream_port, timeout=5)) as upstream:
                upstream.request("GET", self.path, headers={
                    "Accept": self.headers.get("Accept", "*/*"), "Accept-Encoding": "identity",
                })
                with upstream.getresponse() as response:
                    self.send_response(response.status)
                    for name in ("Content-Type", "Content-Encoding", "X-Accel-Buffering"):
                        if response.getheader(name) is not None:
                            self.send_header(name, response.getheader(name))
                    self.send_header("Transfer-Encoding", "chunked")
                    self.send_header("Connection", "close")
                    self.end_headers()
                    if "/woge-patches/" in self.path:
                        content = response.read(BODY_LIMIT + 1)
                        if len(content) >= BODY_LIMIT:
                            raise ValueError("Unexpectedly large captured body")
                        self.chunk(content)
                    else:
                        while content := response.read1(BODY_LIMIT):
                            self.chunk(content)
                    self.wfile.write(b"0\r\n\r\n")

        def chunk(self, content):
            if content:
                self.wfile.write(f"{len(content):x}\r\n".encode() + content + b"\r\n")

        def log_message(self, format, *args):
            pass

    with ThreadingHTTPServer(("127.0.0.1", 0), CaptureHandler) as relay:
        worker = threading.Thread(target=relay.serve_forever, kwargs={"poll_interval": 0.05})
        worker.start()
        try:
            yield relay.server_port
        finally:
            relay.shutdown()
            worker.join(2)
            expect(not worker.is_alive(), "capture relay did not terminate")


class SlowReader:
    def __init__(self, body):
        self.body = body
        self.calls = 0

    def read(self, length):
        chunks = []
        while length:
            time.sleep(0.025)
            self.calls += 1
            chunk = self.body.read(min(128, length))
            if not chunk:
                break
            chunks.append(chunk)
            length -= len(chunk)
        return b"".join(chunks)


def get(conn, path, media, producer):
    conn.request("GET", path, headers={
        "Accept": media, "Accept-Encoding": "identity", "X-Study-Port": str(producer),
    })
    response = conn.getresponse()
    expect(response.status == 200, f"{path} returned {response.status}")
    normalize = lambda value: "".join(value.lower().split())
    expect(normalize(response.getheader("Content-Type", "")).startswith(normalize(media)), "unexpected content type")
    expect(response.getheader("Content-Encoding", "identity") == "identity", "unexpected content encoding")
    return response


def probe(mode, target, origin):
    started = time.monotonic_ns()
    sample = {"mode": mode, "outcome": "error"}
    try:
        with closing(http.client.HTTPConnection("127.0.0.1", target, timeout=5)) as conn:
            with get(conn, SHELL, "text/html", origin) as shell_response:
                shell = shell_response.read(BODY_LIMIT)
            sample["shellMs"] = elapsed_ms(started, time.monotonic_ns())
            document = shell.decode()
            expect(len(shell) < BODY_LIMIT and "<h1>Woge</h1>" in document and
                   document.count('class="is-loading"') == 3 and 'href="' + NATIVE + '"' in document,
                   "the shell is missing visible project context, loading regions or the ordinary complete link")
            metadata = ShellMetadata(document)
            expect(metadata.epoch and metadata.patch_url == f"{SHELL}/woge-patches/{metadata.epoch}" and
                   len(metadata.targets) == 3 and set(metadata.targets.values()) == set(EXPECTED),
                   "wrong shell metadata")
            patch_start = time.monotonic_ns()
            with get(conn, metadata.patch_url, DEFERRED_TYPE, origin) as response:
                sample["headersMs"] = elapsed_ms(patch_start, time.monotonic_ns())
                sample["transport"] = {key: response.getheader(key)
                    for key in ("Server", "Content-Type", "Transfer-Encoding", "X-Accel-Buffering")}
                body = SlowReader(response) if mode == "paced-direct" else response
                expect(body.read(5) == b"WOGE\x01", "wrong framed preamble")
                sample["preambleMs"] = elapsed_ms(patch_start, time.monotonic_ns())
                count = 5
                seen = set()
                frames = []
                for _ in range(3):
                    kind, media, frame, rendered, size = parse_frame(body)
                    region = metadata.targets.get(frame.get("target"))
                    expect(kind == 1 and media == "text/html; charset=utf-8" and region and region not in seen,
                           "wrong frame kind, media or target")
                    expect(frame.get("epoch") == metadata.epoch and frame.get("operation") == "replace" and
                           frame.get("baseRevision") == 0 and frame.get("nextRevision") == 1,
                           "wrong patch metadata")
                    expect(all(marker in rendered for marker in EXPECTED[region]), "wrong region content")
                    frames.append({
                        "region": region, "elapsedMs": elapsed_ms(patch_start, time.monotonic_ns()), "bytes": size,
                        "contentSha256": hashlib.sha256(rendered.encode()).hexdigest(),
                    })
                    count += size
                    seen.add(region)
                kind, media, terminal, rendered, size = parse_frame(body)
                expect(kind == 2 and media == "application/json; charset=utf-8" and terminal == {"patches": 3}
                       and not rendered, "wrong completion frame")
                sample.update(frames=frames, terminalMs=elapsed_ms(patch_start, time.monotonic_ns()),
                              terminal=terminal, bodyBytes=count + size)
                expect(not body.read(1), "bytes after terminal frame")
                if isinstance(body, SlowReader):
                    sample["pacedReadCalls"] = body.calls
        sample["outcome"] = "correct"
    except (OSError, ValueError, http.client.HTTPException) as error:
        sample["problem"] = f"{type(error).__name__}: {error}"
    sample["finishedMs"] = elapsed_ms(started, time.monotonic_ns())
    return sample


def drain(port):
    deadline = time.monotonic() + 2
    connections = tcp_count(port, "01")
    while connections and time.monotonic() < deadline:
        time.sleep(0.05)
        connections = tcp_count(port, "01")
    return connections


def main():
    out = HERE / "proxy-results"
    out.mkdir()
    plan = json.loads((HERE / "control-plan.json").read_text())
    package = json.loads((HERE / "manifest.json").read_text())
    expect(package["sourceCommit"] == plan["sourceCommit"], "the experiment must reuse the declared checkout")
    result = {"plan": plan, "platform": platform.platform(),
              "java": subprocess.check_output(["java", "--version"], text=True).splitlines()[0], "blocks": []}
    content_by_mode = {}
    for index, order in enumerate(SPEC["rotation"]):
        for host_order, host in enumerate(order):
            directory = out / f"round-{index + 1}-{host}"
            directory.mkdir()
            block = {"round": index + 1, "host": host, "serverOrder": host_order + 1, "samples": []}
            with server(host, directory) as (port, _):
                block["nativeControl"] = project_journey(port, time.monotonic_ns(), 2000, native=True)
                rotate = (index + host_order) % len(MODES)
                rotations = MODES[rotate:] + MODES[:rotate]
                with captured_response(port) as relay:
                    for offset, mode in enumerate(rotations, 1):
                        target = PROXY_PORTS.get(mode, relay if mode == "capture-entire" else port)
                        sample = {"order": offset, **probe(mode, target, port)}
                        block["samples"].append(sample)
                        if sample["outcome"] == "correct":
                            content = {f["region"]: f["contentSha256"] for f in sample["frames"]}
                            reference = content_by_mode.setdefault(host, content)
                            if content != reference:
                                sample.update(outcome="error", problem="rendered content changed between transport modes")
                block["freshRequest"] = project_journey(port, time.monotonic_ns(), 2000)
                block["remainingEstablished"] = drain(port)
            block["shutdown"] = json.loads((directory / "shutdown.json").read_text())
            result["blocks"].append(block)
            dump(out / "results.json", result)
            print(host, index + 1, [(s["mode"], s["outcome"], s.get("problem")) for s in block["samples"]], flush=True)
    expect(all(block["nativeControl"]["outcome"] == block["freshRequest"]["outcome"] == "correct" and
               not block["remainingEstablished"] and all(s["outcome"] == "correct" for s in block["samples"])
               for block in result["blocks"]), "one or more transport blocks failed")


if __name__ == "__main__":
    main()
