import contextlib, html, http.client, json, pathlib, re, runpy
shared = runpy.run_path("spikes/todo-next/study.py")
d1 = "/todo-study/deferred"
entries = {
    "woge": ("examples/todo-spring-boot/build/libs/woge-todo-0.1.0.jar", "application/vnd.woge.patch-stream; version=1"),
    "kte": ("spikes/todo-kte-htmx/build/libs/todo-kte-htmx.jar", "text/html"),
    "datastar": ("spikes/todo-datastar/build/libs/todo-datastar.jar", "text/event-stream"),
}
root = pathlib.Path("../jvm-d1-evidence")
results = []
for kind, (file, accept) in entries.items():
    file = pathlib.Path(file).resolve()
    with shared["running"](kind, file, root/f"supplement-{kind}-default.server.log") as (_, port, _):
        with contextlib.closing(http.client.HTTPConnection("127.0.0.1", port, timeout=3)) as conn:
            disabled_status, _ = shared["request"](conn, d1)
            assert disabled_status == 404, (kind, disabled_status)
    with shared["running"](kind, file, root/f"supplement-{kind}-failure.server.log",
                           application_args=("--spring.profiles.active=todo-study-deferred",)) as (_, port, _):
        with contextlib.closing(http.client.HTTPConnection("127.0.0.1", port, timeout=3)) as conn:
            code, shell = shared["request"](conn, d1+"?fail=true")
            assert code == 200, (kind, code)
            path = d1+"/summary?fail=true"
            if kind == "woge":
                path = html.unescape(re.search(rb'data-woge-patch-url="([^"]+)"', shell)[1].decode())
            conn.request("GET",path,headers={"Accept":accept})
            with conn.getresponse() as response:
                body = response.read(512*1024)
                code = response.status
                media = response.getheader("Content-Type")
                assert code == 200 and accept.split(";")[0] in media
                assert b"Todo summary unavailable." in body and b"RuntimeException" not in body
            results.append({"contender":kind,"disabledRouteStatus":disabled_status,"enhancedFailureStatus":code,
                            "enhancedFailureContentType":media,"enhancedFailureBytes":len(body),"safeMessage":True})
            print(results[-1], flush=True)
(root/"supplemental-wire-checks.json").write_text(json.dumps(results,indent=2)+"\n")
