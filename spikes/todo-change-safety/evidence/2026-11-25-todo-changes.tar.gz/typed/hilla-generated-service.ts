import { EndpointRequestInit as EndpointRequestInit_1 } from "@vaadin/hilla-frontend";
import client_1 from "./connect-client.default.js";
import type EditTodo_1 from "./corpus/EditTodo.js";
async function save_1(edit: EditTodo_1 | undefined, init?: EndpointRequestInit_1): Promise<void> { return client_1.call("TodoService", "save", { edit }, init); }
export { save_1 as save };
