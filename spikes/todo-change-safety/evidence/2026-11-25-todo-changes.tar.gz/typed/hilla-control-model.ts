interface EditTodo {
    title?: string;
}
export default EditTodo;
