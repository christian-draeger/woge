interface EditTodo {
    title?: number;
}
export default EditTodo;
